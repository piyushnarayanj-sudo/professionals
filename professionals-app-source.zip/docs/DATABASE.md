# Database design — Professionals

Production storage: managed PostgreSQL. The C server reads `DATABASE_URL` (or common Postgres URL aliases) from its runtime environment. Schema is initialized idempotently at server startup.

## `batsmen`
| Column | Type | Meaning |
|---|---|---|
| `id` | BIGSERIAL primary key | Stable player-entry ID |
| `name` | TEXT NOT NULL | Display name |
| `ones`, `twos`, `threes` | INTEGER NOT NULL, >= 0 | Scoring-shot counts |
| `fours`, `sixes` | INTEGER NOT NULL, >= 0 | Boundary counts |
| `balls` | INTEGER NOT NULL, >= 0 | Balls faced |

Derived `runs = ones + 2×twos + 3×threes + 4×fours + 6×sixes`. Derived `strike_rate = runs × 100 / balls`, zero when balls are zero.

## `bowlers`
| Column | Type | Meaning |
|---|---|---|
| `id` | BIGSERIAL primary key | Stable player-entry ID |
| `name` | TEXT NOT NULL | Display name |
| `runs_conceded` | INTEGER NOT NULL, >= 0 | Bowler's runs conceded |
| `legal_balls` | INTEGER NOT NULL, >= 0 | Exact legal delivery count |
| `wickets` | INTEGER NOT NULL, >= 0 | Entered wickets credited to the bowler |

Derived overs display as `floor(legal_balls/6).(legal_balls mod 6)`. Economy is `runs_conceded × 6 / legal_balls`, zero when no legal ball is recorded.

## `match_settings`
A singleton row (`id = 1`) stores the globally shared active-match labels. Startup creates the table and inserts defaults idempotently.

| Column | Type | Meaning |
|---|---|---|
| `id` | SMALLINT primary key, constrained to 1 | Singleton row identity |
| `team_a_name`, `team_b_name` | TEXT NOT NULL | Editable display names; defaults are `Team A` / `Team B` |
| `batting_team` | TEXT NOT NULL, `team_a` or `team_b` | Manually selected current batting side; it does not alter score calculations |
| `version` | INTEGER NOT NULL | Optimistic concurrency token; increments on each successful update |
| `updated_at` | TIMESTAMPTZ NOT NULL | Last settings update |

`PUT /api/match/settings` requires the current `version`; concurrent stale writes return `409` rather than silently overwriting. The API values are parameter-bound. One row is shared across all visitors because this MVP has one shared scorecard and no sign-in/authentication.

## `match_history`
Stores immutable point-in-time summary snapshots created by `POST /api/history`, including team labels captured in the same archive transaction.

| Column | Type | Meaning |
|---|---|---|
| `id` | BIGSERIAL primary key | Snapshot ID |
| `match_name` | TEXT NOT NULL | User-interface generated or API-supplied label |
| `archived_at` | TIMESTAMPTZ NOT NULL | UTC timestamp |
| `runs`, `wickets`, `legal_balls` | BIGINT NOT NULL | Match totals at archive time |
| `run_rate` | DOUBLE PRECISION | Total runs × 6 / legal balls; null with zero balls |
| `fours`, `sixes` | BIGINT NOT NULL | Boundary totals at archive time |
| `batter_count`, `bowler_count` | INTEGER NOT NULL | Roster counts at archive time |
| `top_scorer`, `top_runs` | TEXT / BIGINT | Highest individual batting score and batter |
| `top_bowler`, `top_wickets` | TEXT / BIGINT | Leading wicket-taker at archive time |
| `team_a_name`, `team_b_name` | TEXT NOT NULL | The two display labels at archive time |
| `batting_team` | TEXT NOT NULL | `team_a` or `team_b` at archive time |

Existing databases receive these columns with `Team A`, `Team B`, and `team_a` defaults via `ADD COLUMN IF NOT EXISTS`; no live score rows or archive records are overwritten. History entries are independent of the live roster, so resetting the active scorecard preserves saved snapshots. The History API returns the most recent 100 records. These are summary snapshots only—not innings player-by-player replays or delivery logs.

## Match summary and integrity
- Total runs, fours, sixes, and balls faced are sums from batting rows.
- Innings overs and run rate use the sum of bowler legal balls.
- Wickets use the sum of entered bowler wickets.
- Top records are derived at read time; ties return every leader.
- All SQL writes use PostgreSQL parameter binding; roster insertion transactions lock the relevant roster table before enforcing the 100-row cap.
- Reset truncates only the live batter and bowler rows and restarts their sequences; archived history and current team settings remain.
- `/api/state` reads players and the singleton settings row through one PostgreSQL connection; team names are serialized as JSON strings and escaped by the existing encoder.
- Archive creation reads the settings row `FOR SHARE` inside its transaction, then writes the labels with the snapshot. Score calculations continue to use the existing batting/bowling rows only.
