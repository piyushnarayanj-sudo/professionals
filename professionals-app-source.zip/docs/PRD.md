# Product requirements — Professionals

## 1. Product summary
Professionals is a responsive cricket scorecard and performance dashboard for recording an innings, comparing player figures, and getting a concise score-aware explanation. The C server and PostgreSQL database are the source of truth.

## 2. Problem and value
Small teams and informal scorers often track figures in notes or spreadsheets. That makes totals easy to miscalculate and comparisons hard to read. Professionals combines validated score entry, automatic calculations, ranked visual comparisons, and an assistant that explains the saved figures.

## 3. Users
- A scorer entering batter and bowler figures during or after an innings.
- A captain or coach comparing batting and bowling contributions.
- A player reviewing a scorecard on a phone, tablet, or desktop.

## 4. MVP scope
### In scope
- Single active scorecard; manual batting and bowling figures.
- CRUD for up to 100 batters and 100 bowlers.
- Automatic runs, strike rate, innings overs/run rate, bowling economy, and leader records.
- Benchmark-style batting and bowling rankings.
- Local Match Analyst Q&A, with optional OpenAI-compatible API adapter.
- PostgreSQL persistence, automatic refresh, responsive layout, demo scorecard, reset, and a summary-snapshot match archive.
- Distinct, direct-link Overview, Performance, Scorecard, History, and Analyst pages with browser back/forward support.

### Out of scope / assumptions
- No ball-by-ball delivery log, extras, dismissal types, targets, innings switching, or full player-by-player multi-match replay. History stores summary snapshots only.
- Wickets are the entered bowler-credit total; run-outs and other non-bowler dismissals are not represented separately.
- No external live cricket feed is connected. This MVP uses manual entries and its own REST API.
- MVP is a single shared scorer workspace; authentication is not implemented.

## 5. Core user journeys
1. Open the dashboard; the app fetches `/api/state` and displays the saved scorecard.
2. Add a batter; enter shot counts and balls faced; preview calculated runs/SR; save.
3. Add a bowler; enter runs, wickets, and overs in cricket notation; save.
4. Compare players in the animated benchmark charts; inspect exact figures in the scorecard tables.
5. Navigate between Overview, Performance, Scorecard, History, and Analyst; direct URLs and browser back/forward work.
6. Archive the live scorecard to History without resetting it; saved snapshots remain after resetting live player rows.
7. Ask the Match Analyst a question or choose a quick prompt; optionally load demo data or edit/delete entries.

## 6. Functional requirements
- Validate non-negative whole-number counts, player names, roster size, and batting shots-versus-balls consistency.
- Treat `4.2` as four overs plus two legal balls, never as 4.2 decimal overs.
- Recompute totals from saved raw counts; viewing/refreshing a summary must not change stored totals.
- Handle zero-ball strike rate/economy safely by showing a dash.
- Expose health, state, CRUD, history read/archive, agent-status, and assistant endpoints; serve every app page path through the C server.
- Escape player names in HTML and JSON output.

## 7. Non-functional requirements
- Responsive from narrow phones to desktop.
- Same-origin API calls; no frontend API secrets.
- PostgreSQL transactions and parameterized SQL.
- Useful empty, loading, validation, offline, and confirmation states.
- Motion respects `prefers-reduced-motion`.

## 8. Acceptance criteria
- A saved entry survives reload/restart.
- Summary and chart values agree with scorecard rows.
- A 4.2-over bowler has economy `runs × 6 / 26`.
- Zero balls never causes a crash or divide-by-zero.
- The app works without an external AI key; optional API failure falls back to local analysis.
- Layout and primary controls remain usable on mobile widths.
