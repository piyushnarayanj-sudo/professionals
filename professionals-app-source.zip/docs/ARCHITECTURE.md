# Architecture — Professionals

```text
Browser
  ├─ Vercel CDN / Container Runtime
  │    └─ C HTTP server (static frontend + same-origin REST API)
  └─ Managed PostgreSQL (Neon via Vercel Marketplace)
       ├─ batsmen
       ├─ bowlers
       └─ match_history

Optional AI: C server → OpenAI-compatible endpoint (key stays server-side)
```

`server.c` remains the application and API core. It uses POSIX sockets and detached pthreads to serve one HTTP request per connection; each database operation opens a libpq PostgreSQL connection, executes parameterized queries, and closes the connection. PostgreSQL is the source of truth so serverless container scale-up/down does not lose or fork score data.

## Data flow

1. Browser reads and edits through same-origin `/api/*` routes.
2. C validates JSON inputs and limits rosters to 100 batters and 100 bowlers.
3. C persists raw inputs and immutable match summaries in PostgreSQL.
4. C derives runs, strike rate, overs, economy, rankings, and local analyst context on reads.
5. Optional external AI receives only server-side requests; if absent or unavailable, the C server answers locally.

## Runtime

- `Dockerfile.vercel` builds the C container for Vercel's Container Runtime and listens on the platform `PORT` (default 80).
- The Vercel filesystem is treated as ephemeral; no score data is written to local container files.
- `Dockerfile` and `compose.yaml` support local container development with PostgreSQL.
- Health endpoint: `/api/health`.
