# Authentication and security boundary

## Current access choice
The requested deployment is a public, editable link. Professionals currently has one shared scorecard and no user accounts; the server exposes write, delete, archive, and reset endpoints without login. Anyone who gets the public URL can reach them.

This is appropriate only for public/demo match data. Do not enter sensitive team or personal information. The Arena preview is a temporary trusted-workspace preview, not an authenticated production service.

## Before using private/team data
Add one of:
- Application authentication with server-side sessions and CSRF protection, or
- A trusted identity-aware reverse proxy that protects every API route.

## Production controls to add
- User/team ownership checks on every match and player row.
- HTTPS only; secure, HttpOnly, SameSite cookies if sessions are used.
- Rate limits, request-size limits, audit logs, backups, and restore tests.
- Secrets only in deployment environment/secret manager. Never return `AI_API_KEY` to `/api/agents` or the browser.
- CORS allowlist if the API is split across origins; otherwise keep same-origin.
- Review reset authorization and confirm destructive actions.

## Current protections
Input range checks, roster caps, prepared PostgreSQL writes, HTML escaping, bounded request bodies, TLS certificate verification for optional AI calls, and local fallback when an external call fails. These protections do not replace authentication or authorization.
