# Feature guide

## Independent feature pages
- **Overview** (`/overview`) — current innings score, quick match numbers, and a cinematic cricket-night introduction with a slow crossfading carousel of the five user-supplied arena images.
- **Performance** (`/performance`) — scroll-led innings story, batting/bowling benchmarks, and standout figures, now presented on high-contrast glass panels with staggered story, chart, and record-card animations.
- **Scorecard** (`/scorecard`) — manual batter/bowler entry, editing, deletion, and demo data.
- **History** (`/history`) — archive and revisit point-in-time PostgreSQL snapshots of score, overs, run rate, team names, batting side, top scorer, and leading bowler. Saving history does not clear or alter the live scorecard; resetting live player rows does not delete snapshots.
- **Analyst** (`/analyst`) — local score-aware Q&A and optional server-side external AI.
- **Sign-In** (`/` and `/signin`) — visual-only opening splash with stadium/drone video and supplied-photo wallpaper sequence. Completing guest entry opens Overview at `/overview`; no authentication is performed or added.

Each feature is an independent route; only the selected page is shown. Sticky navigation changes pages and URLs, with browser back/forward support. Page content can scroll vertically, with a distinct arena wallpaper that subtly shifts with scrolling. The splash is not authentication; direct feature routes and the public API remain accessible. Reduced-motion preferences disable wallpaper/photo movement and smooth scrolling.

## Score entry
- Batter form records ones, twos, threes, fours, sixes, and balls faced; preview shows calculated runs and strike rate.
- Bowler form records runs conceded, wickets, and overs using cricket notation (`3.4` = 3 overs + 4 legal balls).
- Edit/delete controls are available beside each row; destructive actions require confirmation.

## Match overview
- Hero shows total runs/wickets, innings overs, run rate, and batter count, alongside the shared team names and current batting-side label.
- Scorecard settings allow editing Team A / Team B display names and the manually selected batting side. They are global for the single shared scorecard; a version token prevents silent stale overwrites. Changing labels does not change score data.
- Metric cards total fours, sixes, balls faced, and players.
- Score values are recalculated from the saved player rows. Archived snapshots retain the team labels and batting side that were current at archive time.

## Performance lab
- Batters are ranked by runs; horizontal bar width is the fraction of the leader's score. Numeric run and strike-rate figures remain visible.
- Bowlers are ranked by wickets, then economy. Economy is shown as runs per over based on exact legal-ball count.
- Record cards show top scorer, most fours, most sixes, and most wickets; ties are retained.

## Match Analyst
- Quick prompts cover leading scorer, run rate, and bowling leader.
- Free text questions route to local score-aware analysis.
- Optional external model calls are server-side only, use the current scorecard as context, and fall back locally on failure.

## Demo and persistence
- Load a sample card to see meaningful bars and comparisons.
- The demo button hides when real data exists; reset is available in the sidebar.
- PostgreSQL persistence survives refresh and server restart. Polling refreshes other open tabs/devices.
- Match-history entries are summary snapshots, not ball-by-ball or full innings replays; the API returns the newest 100.
