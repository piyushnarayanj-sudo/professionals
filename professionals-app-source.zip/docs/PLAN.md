# Step-by-step implementation plan

This plan follows the workflow shown in the reference reel. Completed items describe the current local MVP; public production deployment remains a separate stage.

| Step | Deliverable | Current status |
|---|---|---|
| 1. PRD | Users, scope, journeys, acceptance | `PRD.md` complete |
| 2. Design | Benchmark ranking visual language, motion, responsive system | `DESIGN.md` and `index.html` complete |
| 3. Architecture | Browser → C REST server → PostgreSQL; optional AI adapter | `ARCHITECTURE.md` complete |
| 4. Database | Batter/bowler schema, constraints, formulas | `DATABASE.md` complete |
| 5. API | REST contracts and errors | `API.md` complete |
| 6. Agents | Local Match Analyst + Data Guard; optional external model | `AGENTS.md` complete |
| 7. README | Setup, features, configuration | Root `README.md` complete |
| 8. Implementation | C HTTP API + responsive cricket dashboard | MVP implemented |
| 9. Setup | GCC/PostgreSQL/libcurl build and run | `SETUP.md` complete |
| 10. Features | Score entry, charts, assistant, demo/reset | `FEATURES.md` complete |
| 11. Authentication | MVP boundary and production hardening | `AUTHENTICATION.md` complete |
| 12. MCP | Decision and future tool boundary | `MCP.md` complete |
| 13. Integrations | PostgreSQL, optional AI, no live-feed provider | `INTEGRATIONS.md` complete |
| 14. Testing/QA | Build/API/formula/assistant/responsive checklist | `TESTING.md` complete |
| 15. Debugging | Common build/server/data/AI issues | `DEBUGGING.md` complete |

## MVP phases
1. **Plan:** confirm scope, manual scoring, scorecard limitations, and references.
2. **Backend:** keep calculations and persistence in C/PostgreSQL; validate every write.
3. **Frontend:** implement mobile-first score hero, metric cards, animated benchmark charts, scorecard tables, and dialogs.
4. **Agent:** ship local score-aware Q&A and optional external adapter with fallback.
5. **QA:** compile with warnings, exercise API and formulas, test mobile/reduced motion, verify no secret reaches the browser.
6. **Deploy:** choose a host, configure TLS/domain/auth/backups and API credentials; then run production checks.

## Next production milestones
- Add match/team metadata and match history.
- Add ball-by-ball events, extras, dismissal types, undo, and innings switching.
- Add authentication and role/ownership model.
- Select and license an external score feed if automatic live scores are required.
- Add automated browser tests and deployment pipeline.
