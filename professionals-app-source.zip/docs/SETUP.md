# Setup and run

## Prerequisites
- C11 compiler (GCC or Clang).
- POSIX sockets/pthreads (Linux/macOS supported by this implementation).
- PostgreSQL client/development library and headers (`libpq-dev` on Debian/Ubuntu).
- libcurl development library and headers (the optional AI adapter is compiled in).

## Build
From the project root:

```bash
make clean
make
make test
```

## Run
Set a PostgreSQL connection URL, then start the server:

```bash
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require" ./scorecard_server
```

Open `http://localhost:8000`. The server binds to `0.0.0.0`, so another device on the same trusted network can connect if the host firewall allows it.

## Environment

```bash
PORT=8080 DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require" ./scorecard_server
SCORECARD_ROOT=/path/to/site DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require" ./scorecard_server
```

`DATABASE_URL` (or a supported Postgres URL alias) is required. `SCORECARD_ROOT` must contain `index.html` and the `assets/` folder. For local schema and feature tests, point `DATABASE_URL` only at an authorized isolated test database or the separate free Neon Preview branch—never Production. Startup applies idempotent schema creation/column additions, including the `match_settings` singleton; verify the connection target privately before starting the server.

`make test` runs C parser/validation tests for the match-settings input and JSON encoding; it does **not** connect to PostgreSQL or verify database migrations/transactions. A database-backed smoke test is still required before deployment.

Optional compatible AI endpoint:

```bash
AI_API_KEY='server-side-secret' \
AI_API_URL='https://api.openai.com/v1/chat/completions' \
AI_MODEL='gpt-4o-mini' \
DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require' \
./scorecard_server
```

Do not place the AI or database credential in `index.html`, a query string, or a public repository.

## Same-network device access
Find the host machine's LAN IP, keep the server running, and open `http://HOST_LAN_IP:8000` on another device on the same network. This is for trusted local testing only; use HTTPS and authentication before public deployment.
