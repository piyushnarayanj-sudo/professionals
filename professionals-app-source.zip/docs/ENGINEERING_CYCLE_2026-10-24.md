# Engineering improvement cycle — 2026-10-24

## Follow-up — Performance readability and animation pass (2026-10-25)

The user reported that Performance-page text was hard to read against the new wallpaper and requested more motion.

- Darkened the Performance wallpaper layer, added dark glass backplates behind story and benchmark copy, brightened text, and increased supporting-text/chart-label sizes for clearer hierarchy.
- Added a coordinated set of staggered route/section entrances, story-card sheen and metric transitions, pulsing timeline markers, moving progress and benchmark bars, staggered chart/record cards, and button hover feedback. Animations are CSS-driven and respect reduced-motion preferences.
- Root, app-bundle, and visual-preview HTML are synchronized at SHA-1 `2de462602309fea26e662b47ed88a9f514415473`; the frontend patch and compressed artifact were regenerated and strictly verified. Inline JavaScript/static checks passed. Browser visual QA was unavailable; the refreshed preview should be checked for perceived contrast and motion.
- No database/scoring changes or deployment were made.

## Follow-up — independent feature pages and scrolling wallpapers (2026-10-25)

The user requested that Overview, Performance, Scorecard, History, and Analyst become separate pages with a scrolling-wallpaper theme. The Sign-In opening splash remains the root experience.

- The frontend now displays only the active feature route. `/` and `/signin` remain visual-only entry; successful guest entry opens `/overview`. Performance, Scorecard, History, and Analyst retain their own direct routes, with browser history support.
- Added `/overview` and `/overview/` to the C server’s HTML route whitelist and to the static preview. Each feature page keeps its distinct supplied-arena artwork; the wallpaper remains in view and shifts subtly with scroll. Reduced-motion mode disables the drift.
- `make -B` and `make test` pass, including C socket-pair checks for both Overview route forms. Inline JavaScript and static route/layout checks pass; root/app/preview HTML copies are byte-identical at SHA-1 `95452ee1bb178d90339a25e0a246bf78bf027072`. The refreshed preview returned HTTP 200 for all feature routes and media assets; its `/api/state` remains the expected static-only 503.
- No database/scoring logic or Production deployment changed. Browser review is still required for page isolation, nav/history transitions, wallpapers, responsiveness, and motion preferences. The local preview remains static and has no connected C API/database.

## Follow-up — supplied backgrounds and continuous scrolling (2026-10-24)

The user requested replacement of the previous static background artwork with five attached cricket-stadium images and conversion of the site into a continuous scrolling experience. The existing workspace was updated; no Vercel deployment was attempted.

- Converted the five supplied images into local optimized WebP assets: `match-arena-sunset.webp`, `match-arena-aerial.webp`, `match-arena-futuristic.webp`, `match-arena-fireworks-wide.webp`, and `match-arena-fireworks-field.webp`.
- Replaced the old static background paths. Overview uses the five supplied images; after the 2026-10-25 clarity follow-up, Sign-In uses the three highest-resolution supplied photos at near-full opacity, timed across the opening sequence, then switches to the existing drone video. Each primary section uses a supplied image with gentle pan/zoom. The photos are still images, not live or real-time imagery. Reduced-motion mode uses static images/posters and disables smooth scrolling.
- The root URL now opens a full-screen visual-only Sign-In splash. Submitting the guest form reveals the five vertically stacked core sections—Overview, Performance, Scorecard, History, and Analyst—with sticky navigation, scroll-spy state, and direct routes/history navigation. The splash is not authentication; the API remains unchanged.
- Root, app-bundle, and visual-preview HTML are byte-identical at SHA-1 `85d9799acb77574e85767fbde011052ec6f30ca6`. The frontend-only patch reproduces that HTML from the recorded old baseline with `--fuzz=0`; image assets are separate bundle files.
- C build and unit tests passed; the C server now whitelists all five WebP routes and returns the correct MIME type, verified through socket-pair tests. Inline JavaScript syntax and static markup checks passed. The local static preview routes and photo assets returned HTTP 200; `/api/state` returned the expected 503 because the C API/database are not connected.
- No browser automation was available. Visual crops, actual scroll interactions, motion/reduced-motion behavior, keyboard/touch behavior, and responsive layouts still need human browser review. The user-supplied Vercel project was reported deleted; no replacement project or deployment was created.

## Scope and outcome

This iteration implemented one focused, additive improvement: editable shared team names and a manually selected batting-side label. The existing C server remains the scoring/API core; scores, run rates, strike rates, bowling economy, and manual entry are unchanged. The app still has its existing five main pages. Team metadata is a single global setting because the MVP has one shared scorecard and no authentication.

The change is implemented in the workspace but **not deployed** and **not yet verified against PostgreSQL**. Keep it separate from Production until the database migration and browser checks pass on the separate free Neon Preview branch.

## Implemented

- Added an idempotently created `match_settings` singleton with `team_a_name`, `team_b_name`, `batting_team`, `version`, and `updated_at`.
- Added `PUT /api/match/settings`; the API trims and validates names (1–60 Unicode code points), uses parameterized SQL, and requires `expected_version`. Stale edits return `409 Conflict` rather than silently overwriting another visitor's settings.
- `/api/state` returns match settings alongside the existing scorecard and calculated summaries. It reads player rows and match settings through one PostgreSQL connection.
- The current innings hero and Scorecard page show the team pair and batting side. A clear modal says labels are shared/public and saving does not alter score figures.
- `match_history` snapshots capture team names and batting side in the archive transaction. Existing rows receive `Team A`, `Team B`, and `team_a` defaults through `ADD COLUMN IF NOT EXISTS`; reset still clears only batters and bowlers and preserves both history and team settings.
- Added `make test` and C unit coverage for whitespace normalization, escaped quotes, Unicode escapes, control characters, length bounds, batting-side validation, version validation/overflow, and JSON escaping.

## Checks completed in this iteration

- C server build: `make -B` passed with `-std=c11 -O2 -Wall -Wextra -Wpedantic`.
- C parser unit tests: `make test` passed.
- Inline JavaScript passed `node --check`; static HTML inspection found 140 unique IDs, preserved all five main navigation links plus `/signin`, and found each new metadata-control ID exactly once. A static check also confirmed the stale-version form refresh path is present; the interaction itself is not browser-tested.
- Root, app-bundle, and visual-preview HTML files are byte-identical at SHA-1 `c36f1ef44553c800dc0ee748f5e6487a2de40b27`. The frontend-only `performance.patch` was rebuilt from the prior public baseline SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f`, applied with `--fuzz=0`, and reproduced the new HTML exactly. This simulation does **not** include or verify the C backend/DB migration and is not a deployment.
- The restarted static preview served `/`, `/signin`, `/performance`, `/scorecard`, `/history`, `/analyst`, and the four Sign-In media assets with HTTP 200. `/api/state` returned the expected static-preview-only HTTP 503. This validates static routing/assets, not the live C API or database.
- The active C scoring formulas were not edited.

### Not verified yet

- No PostgreSQL client/server or Docker is installed in this environment. The new DDL, migration, parameterized update, stale-write behavior, archive capture, and reset semantics have not been exercised against a real PostgreSQL instance.
- No browser automation binary/library was available. The new modal, page-to-page display, keyboard/accessibility behavior, and mobile/responsive rendering have not received a browser QA pass.
- No Production or Preview database writes were made. No Vercel deployment was attempted; prior Vercel access was denied and has not been retried.
- No fresh load test, accessibility audit, or real-device performance measurement was run.

## Reference-image review

The earlier reference-image review described stadium fireworks, a sunset-lit arena, and a stylized futuristic cricket arena. At that earlier point those references were not copied into assets. In the later follow-up, the user explicitly supplied five new background images; those have now been converted and added to product assets as documented above. Existing Sign-In stages remain visual-only with stadium footage in stages 1–2 and the aerial scene in stage 3, now layered with the supplied photos.

The available encoded videos remain 27 seconds at 1280×674/24 fps and 14 seconds at 1280×720/24 fps. No video-generation tool was available. **The seamless 30-second and 4K-master targets remain unmet**; playback-rate configuration, decoded frames, and poster fallbacks do not constitute a 30-second/4K generated source.

## MiroFish and load-test findings

- No MiroFish repository was found under `/home/user`; no local installation/configuration was available to run.
- The official [MiroFish repository](https://github.com/666ghj/MiroFish) describes a multi-agent AI prediction/social-simulation engine, not a generator of real concurrent HTTP clients. Its documented setup requires Node.js 18+, Python 3.11–3.12, `uv`, and server-side LLM/Zep API credentials; it is AGPL-3.0 licensed. It was inspected read-only, not installed or integrated. No secrets were requested or configured.
- `k6`, Locust, `wrk`, `hey`, ApacheBench (`ab`), Playwright/browser binaries, and Docker were not available locally. A true 10,000-client run was not performed.
- Exact load/simulation counts: **0 MiroFish agents; 0 concurrent HTTP clients**. No duration, RPS, latency percentiles, error rate, CPU, memory, or database metrics exist. Agent behavior and HTTP load must remain distinct in any future report.

## Live-score provider review

No provider was selected or integrated. Official [CricketData pricing](https://cricketdata.org/pricing/) advertises 100 free API hits/day; its [terms](https://cricketdata.org/terms-of-use/) distinguish personal/non-commercial use from commercial use requiring purchased credits and an API key. Its [API guide](https://cricketdata.org/how-to-use-cricket-data-api.aspx) warns that some series/matches have partial coverage; the current-match endpoint is not a comprehensive upcoming-fixtures feed. Its own pages also describe delayed data, so the product must not imply a guaranteed real-time feed.

API-SPORTS was also reviewed. Its [terms](https://api-sports.io/terms) state that it does not provide a publication license for competition data and place rights clearance on the developer; its free quota is also limited. That is not a safe default for a public worldwide-score hub.

No paid service, API account, key, or external score request was configured. Before implementation, confirm the intended commercial/publication use, coverage, lag, usage quotas, and written data-display rights. Keep any key server-side. Never scrape restricted sites or present cached/stale values as current.

## Open issues, ranked

### P0 — complete before using this iteration on a shared deployment

1. Run startup migration and functional tests against the separate free Neon Preview branch only: load defaults, edit names, force a stale-version `409`, verify `/api/state`, archive the labels, and confirm reset preserves metadata/history. Do not point this test at Production.
2. Run browser QA for team editing and five-page synchronization at desktop/tablet/mobile widths, keyboard-only interaction, focus behavior, screen-reader labels, HTML console/network errors, and sign-in video behavior. Fix any regression before release.
3. Keep the public, unauthenticated write/reset API explicitly treated as open. Visual Sign-In is not authentication; do not put sensitive match data on this service.

### P1 — still requested, not implemented

1. **Active-session indicator:** absent. There is no presence endpoint/table. Do not show a count until it measures deduplicated anonymous browser sessions with a documented ID scope, heartbeat, five-minute inactivity window, privacy policy, abuse/rate-limit strategy, and visible unavailable state. Do not label anonymous sessions as authenticated users.
2. **Worldwide Live Cricket hub:** absent. Blocked on provider publication rights, coverage/latency, and an approved server-side credential. No fabricated/sample scores should be shown as live.
3. **MiroFish and HTTP load test:** absent. First choose whether a synthetic behavioral simulation is actually useful. Use a separate authorized HTTP load generator for concurrent clients; test only an isolated Preview/test environment with synthetic data.
4. **Sign-In 30-second / 4K master:** absent. Current compatible scenes are preserved, but duration/resolution targets are not met.

### P2 — broader hardening

- Obtain browser, responsive, WCAG/accessibility, keyboard, and physical-device performance coverage.
- Evaluate public API write/reset exposure and add an authenticated proxy/application authorization only after a separate product/auth decision.
- Add observability for API/database errors and persistence latency before any scale claims.

## Release and setup status

- Canonical editable source: `/home/user/index.html` and `/home/user/professionals-vercel-app/server.c`.
- New build/test path: `make -B` and `make test` from `professionals-vercel-app/`.
- Private test database only: use the separate free Neon Preview branch; never copy its connection string into chat or source control.
- The owner reports the previous Vercel project was deleted. No replacement project or deployment has been created; the Vercel connector still denies project/deployment reads, and the old URL's availability is unverified. The last recorded pre-deletion HTML baseline was SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f`.
- No load-test report or deployment claim should be made until the corresponding checks actually run.
