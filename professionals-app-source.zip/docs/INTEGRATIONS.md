# Integrations

## First-party C REST API
The frontend and any same-origin client use the API in `API.md`. It is the authoritative read/write boundary for match data.

## PostgreSQL
Production persistence uses a managed PostgreSQL database connected through Vercel Marketplace (Neon). The C server reads the connection string from `DATABASE_URL` (or a supported Postgres URL alias) and creates its tables at startup. No score data is stored in the Vercel container filesystem.

## Optional OpenAI-compatible AI
The C server uses libcurl to call a Chat Completions-compatible endpoint only when `AI_API_KEY` is set. `AI_API_URL` and `AI_MODEL` are configurable. The request includes the user's question and minimal scorecard context. TLS verification is enabled. Credentials remain server-side. Local intent-based analysis is the default and fallback.

## External cricket score feeds
No provider is currently connected. Scoring is manual through the C API. Provider review on 2026-10-24 did not identify a safe production choice:

- CricketData.org's official pages advertise a 100-hit/day free tier. Its terms describe non-commercial use as the free-site permission, say commercial use requires purchased credits, and do not grant broad third-party competition rights. Its documentation also warns that series/matches may have partial coverage; the current-matches endpoint is not a complete future-fixtures feed. Do not integrate or display scores publicly until use rights and coverage are confirmed. No paid service or API key was configured.
- API-SPORTS advertises 100 free requests/day, but its terms say it does not grant publication rights for the data and place competition licensing on the developer. This is not an automatic safe alternative.

Before adding a feed: obtain explicit rights for the intended public/commercial display, confirm international/domestic coverage and latency, keep keys server-side, cache/rate-limit centrally, show source and last-updated time, and preserve manual override. Never scrape restricted sites or label cached data as live/current.

## MCP
Deferred; see `MCP.md`.
