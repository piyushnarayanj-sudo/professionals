# Deploy Professionals on Vercel

## Current iteration status — 2026-10-24

The owner reported that the previous Vercel project was deleted. No replacement project has been created, and the current workspace changes—including independent feature-page routes, scrolling wallpapers, and user-supplied photos—have **not** been deployed or run against a database. The previously recorded Production HTML baseline SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f` predates these changes; availability of the old public URL is not verified. Do not describe the workspace preview as live Production.

Before any Production release, create/reconnect a Vercel project and first point a private Preview runtime only at the separate **free Neon Preview branch**. Verify the idempotent `match_settings` / `match_history` migration, update conflict handling, state read, archive snapshot, and reset behavior. Never point migration smoke tests at Production. Keep database/provider credentials in private server-side environment configuration; do not put secrets in chat or source control. Vercel project access previously returned Access denied and must be verified before deployment.

## Previous project configuration (historical; owner reports project deleted)

- **Former public app:** <https://professionals-cricket.vercel.app> — current availability not checked.
- **Former deployment:** `professionals-cricket-a7nb18q4m-piyushnarayanj-3935.vercel.app`.
- **Former Vercel project:** `professionals-cricket`.
- **Runtime:** C server in a Vercel Container Runtime image.
- **Database:** `professionals-db`, Neon PostgreSQL on the **Free** plan, previously connected through Vercel Marketplace. Do not assume this resource is still connected to a replacement project.
- **AI:** optional external AI was not configured; the local C analyst works without an AI key.

Historical read-only verification for an earlier deployment checked public access, the visual-only `/signin` guest entry, five main routes, and then-current scene assets. At that time `GET /api/health` reported C/PostgreSQL healthy and the scorecard/history were empty. These checks predate the current workspace changes and are not a fresh Production smoke test.

## Architecture

The C server remains the application/API core. `Dockerfile.vercel` builds it into a container; Neon PostgreSQL stores scorecard and history data. The frontend and API are served from the same C server/origin. This avoids relying on Vercel's temporary function filesystem for durable match data.

`professionals-vercel-app/vercel.json` explicitly declares the `professionals` service with `runtime: "container"`, uses `Dockerfile.vercel` as its entrypoint, and routes all public paths to it. `professionals-vercel-app/` is the linked Vercel deploy bundle; the project root remains the canonical editable source and docs.

The Container Runtime and Vercel Services are currently Beta features. Vercel's container image listens on the runtime-provided `PORT` (default 80). See [Container Runtime](https://vercel.com/docs/functions/runtimes/container) and [Services](https://vercel.com/docs/services). Vercel's function filesystem is temporary, which is why Postgres is used for persistence: [Vercel runtimes](https://vercel.com/docs/functions/runtimes).

## Database and environment

The previously configured Vercel Marketplace Neon integration supplies `DATABASE_URL` plus provider aliases to its configured environment. The C server reads `DATABASE_URL` first and supports common PostgreSQL URL aliases. At startup it creates `batsmen`, `bowlers`, `match_history`, and the singleton `match_settings` table when missing, and adds the new team-label columns to older history tables idempotently. Verify this startup migration only against the separate free Neon Preview branch until the new code has passed database-backed smoke tests.

Keep database credentials in Vercel environment variables. Do not commit `.env` files or paste credentials into chat. The Neon resource is on plan ID `free_v3` (Free); do not switch to a paid plan without explicit approval.

## Deploying an update

A former Vercel project link may still be stored in `professionals-vercel-app/.vercel/`; because the owner reports that project deleted, treat that link as stale and re-link only after a new project is intentionally created. For a future authorized release, sync `server.c`, `Makefile`, `index.html`, `Dockerfile.vercel`, and `assets/` into the bundle. Run database-backed regression and browser checks against the separate free Neon Preview environment before creating any deployment.

The Vercel connector has returned Access denied for project and deployment reads. Do not claim deployment or assume the old URL is active. Do not pull Production variables into a tracked/source directory. Once a new project is created, access is restored, and Preview tests pass, follow the authorized Vercel release path.

Do not run a Production Neon install or attach the Preview database to Production for this iteration. If a test environment needs Neon, use the separate free Preview branch, verify its branch/database identity privately before starting the C server, and keep its URL only in the Preview environment's server-side variables. Never pull database credentials into the project folder. No new Neon resource or paid plan was created or approved here.

## Verification endpoints

- `GET /api/health` — returns `status: ok`, `storage: postgresql`, `backend: c`.
- `GET /api/state` — current live scorecard, calculated summary, and shared team settings (in the updated local workspace; Production has not been updated).
- `PUT /api/match/settings` — version-checked team-label and batting-side update (in the updated local workspace; not yet deployed).
- `GET /api/history` — saved match snapshots, including archived team labels (in the updated local workspace).
- `/` and `/signin` — visual-only guest entry; they do not authenticate or gate the API.
- `/overview`, `/performance`, `/scorecard`, `/history`, `/analyst` — separate Overview, Performance, Scorecard, History, and Analyst pages.
- `/assets/match-arena-sunset.webp`, `/assets/match-arena-aerial.webp`, `/assets/match-arena-futuristic.webp`, `/assets/match-arena-fireworks-wide.webp`, `/assets/match-arena-fireworks-field.webp` — user-supplied photo backgrounds served as `image/webp` by the updated C server.
- Existing Pexels Sign-In stadium/drone video loops remain available for the visual-only entry sequence; each feature page has a distinct supplied-photo wallpaper.

Scoring is manual through the UI/C API; there is no external live-score feed. The five feature pages and the visual guest-entry screen share one public C/PostgreSQL service.

## Public-access warning

You chose a public, editable link. Vercel Authentication protection is disabled for this project. The `/signin` screen is visual only: the player tag and role are presentation preferences, not credentials, and do not gate the site or API. Anyone who reaches the URL can read or change scores, delete players, archive history, and reset the live roster. Use only public/demo data until app-level authentication and authorization are added.

## Optional AI

The Analyst works locally by default. If you later configure an OpenAI-compatible provider, add `AI_API_KEY`, `AI_API_URL`, and `AI_MODEL` as server-side Vercel Production variables. Never expose the key to browser code; the app falls back to local analysis if external AI is absent or fails.
