# REST API — Professionals

All routes are same-origin and return JSON. Writes accept `Content-Type: application/json`. Errors use `{ "error": "..." }`.

## Health and data
### `GET /api/health`
Returns server/storage/backend status, e.g. `{ "status":"ok", "storage":"postgresql", "backend":"c" }`.

### `GET /api/state`
Returns `match`, `batsmen`, `bowlers`, calculated `summary`, and `records`. `match` contains `team_a_name`, `team_b_name`, `batting_team` (`team_a` or `team_b`), and a monotonically increasing `version`. Computed rate fields are `null` when their denominator is zero.

### `PUT /api/match/settings`
Updates the single shared match's display names and manually selected batting team. It changes metadata only; the C scoring calculations and current player figures are untouched. Names are trimmed, required, and limited to 60 Unicode code points.

```json
{"team_a_name":"Hyderabad Sunrisers","team_b_name":"Mumbai Indians","batting_team":"team_a","expected_version":7}
```

`expected_version` must match the version returned by `GET /api/state`. A stale update returns `409 Conflict` instead of overwriting another user's changes. This remains a public unauthenticated write route, like the rest of the MVP API.

### `GET /api/agents`
Returns available agent names/modes and whether an external AI key is configured. Does not expose credentials.

## Batters
`POST /api/batsmen` creates a player (201). `PUT /api/batsmen/{id}` replaces that entry (200). `DELETE /api/batsmen/{id}` removes it (200).

```json
{"name":"A. Sharma","ones":12,"twos":3,"threes":0,"fours":5,"sixes":2,"balls":40}
```

## Bowlers
`POST /api/bowlers`, `PUT /api/bowlers/{id}`, and `DELETE /api/bowlers/{id}`.

```json
{"name":"J. Bumrah","runs_conceded":18,"legal_balls":24,"wickets":2}
```

The browser accepts overs notation and converts it to exact legal balls before posting.

## Match history
### `GET /api/history`
Returns the 100 most recent archived scorecard snapshots, newest first. Each entry includes `id`, `name`, UTC `archived_at`, `runs`, `wickets`, `legal_balls`, cricket-format `overs`, `run_rate`, `fours`, `sixes`, `batter_count`, `bowler_count`, `top_scorer`, `top_runs`, `top_bowler`, `top_wickets`, `team_a_name`, `team_b_name`, and the archived `batting_team`. Existing snapshots receive the legacy-safe `Team A` / `Team B` defaults during the idempotent schema migration.

### `POST /api/history`
Archives the current live scorecard summary in PostgreSQL without changing the active scorecard. At least one batter or bowler must be present.

```json
{"name":"Match · 18 Oct 2026, 10:30 am"}
```

Returns `201` with `{ "id": 1, "status":"archived" }`. The frontend generates a timestamped title automatically. History entries are summary snapshots, not ball-by-ball records.

## Analyst
### `POST /api/assistant`
```json
{"question":"Who is the top scorer?"}
```
Returns `{ "agent":"Match Analyst", "mode":"local|local-fallback|external-api", "answer":"..." }`. No key is needed for local analysis. External AI is called only when configured on the server.

## Reset
`POST /api/reset` clears the live batter and bowler tables and resets their PostgreSQL sequences. **It does not delete archived entries in `match_history` or reset `match_settings`.** The UI asks for confirmation.

## Status codes
- `200` success; `201` created.
- `400` validation error; `404` missing route/player; `409` stale match-settings version; `413` oversized body; `500` server/database failure.

## Security and data scope
The MVP is a single shared, unauthenticated scorecard—not a protected sign-in system. Team names and the batting-side label are global match metadata visible to all visitors. Anyone with the public link can edit settings or other API data. Do not expose write/reset routes to the public internet without an authenticated reverse proxy or future application-auth decision.
