# Debugging guide

## Build fails on `libpq-fe.h` or `curl/curl.h`
Install the PostgreSQL client/development package (`libpq-dev` on Debian/Ubuntu) and libcurl development package, then rerun `make clean && make`.

## `DATABASE_URL` is missing or PostgreSQL connection fails
Set the managed Postgres connection URL in the runtime environment. Check that the Vercel Neon integration is connected to Production and that the URL contains the correct TLS settings. Never print or paste the URL; it contains credentials.

## `bind: Address already in use`
Another process is using the selected port. Stop it or run `PORT=8080` and open port 8080.

## Website loads but says server offline
Keep the C server running, confirm the browser URL uses the same host/port, and check `/api/health`. The frontend calls relative `/api/...` routes.

## Scores or rates look unexpected
- Runs are computed from the shot counts; there is no extras field in the MVP.
- Innings overs/run rate sum bowlers' legal balls, not batter balls faced.
- `4.2` means 26 balls, not 4.2 decimal overs.
- Strike rate/economy are blank until their denominator is nonzero.
- Bowler-credit wickets are summed; non-bowler dismissals are not modeled separately.

## Assistant answers locally instead of using the model
Local mode is default. Set `AI_API_KEY`; optionally set `AI_API_URL`/`AI_MODEL`; restart or redeploy; then check `/api/agents`. Invalid keys, timeouts, or incompatible response bodies fall back to local mode. Never paste a production key into frontend files.

## API request errors
The API returns JSON `{ "error": "..." }`; check the response and C server logs. Counts must be non-negative integers; batting scoring shots cannot exceed balls faced; rosters cap at 100.
