# MCP integration decision

## Current state
No Model Context Protocol server is required for the MVP. The C REST API already supplies the tools the browser and Match Analyst need, so adding an MCP layer now would duplicate functionality and increase operational complexity.

## Future MCP seam
If a desktop assistant or external agent needs Professionals tools, create a separate authenticated MCP adapter that calls the C REST API rather than opening PostgreSQL directly. Start with read-only tools:
- `get_scorecard`
- `get_leaderboards`
- `get_match_insights`

Only add write tools (add/edit/delete/reset) with explicit user confirmation, authorization, audit logging, and strict schema validation. Never expose an unauthenticated MCP server on the public network.
