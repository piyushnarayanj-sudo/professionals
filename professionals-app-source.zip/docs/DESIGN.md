# Design system — Professionals

## Visual direction
The visual reference is Techfest's current landing-page treatment: a persistent horizontal navigation, large illustrated night-world hero composed of separate sky/architecture/character layers, atmospheric fog, a clear scroll cue, and long-form sections presented like event posters/cards. Professionals adopts those broad frontend patterns without using Techfest branding, copy, or artwork. The adaptation is a cricket-night arena with original art, score-led cards, route-specific title panels, and a dark readable data UI.

Keep the benchmark-chart language cricket-native: runs/wickets are the score, the leader is the baseline, and each bar shows relative impact.

## Design principles
1. **The score comes first:** innings total, wickets, overs, and run rate remain explicit in the hero.
2. **Immersion, not imitation:** use layered atmospheric depth and scroll-led storytelling; preserve Professionals's own identity and imagery.
3. **Compare at a glance:** horizontal bars rank batters by runs and bowlers by wickets; supporting figures remain visible.
4. **Keep it cricket-native:** partial overs use legal-ball notation; never imply decimals are a base-10 over count.
5. **Graceful without motion or network:** CSS/JS are embedded, artwork is served locally, charts have text labels, and reduced-motion settings are honored.

## Color and type
- Midnight-indigo canvas with deep navy surfaces; a restrained antique-gold/ivory highlight palette and misty teal depth accents.
- Original layered arena artwork supplies the illustration, pavilion silhouette, floodlights, pitch, and atmospheric haze.
- Bright data colors remain distinct in chart bars; score text and table values keep strong contrast over dark surfaces.
- Editorial serif display headlines pair with the existing system UI font for controls and data; no external font/CDN dependency.

## Layout and components
- Desktop: persistent horizontal glass navigation, compact sticky match-control bar, full-bleed Overview hero, and centered page content.
- Mobile: compact two-row sticky navigation with five routes, stacked hero/cards, horizontally scrollable score tables, and touch-sized controls.
- Direct-link pages: Overview, Performance, Scorecard, History, and Analyst. Browser back/forward and active route state are supported.
- Performance contains the scroll-led match story and batting/bowling rankings; Scorecard keeps manual editing tables; History stores PostgreSQL summary snapshots; Analyst is a separate Q&A page.
- Other pages use illustrated poster-style title panels with corner glow, fine gold rules, and reusable dark content cards.
- Chart columns follow the reference benchmark pattern: rank, player/secondary data, bar, primary score, comparison/economy.

## Motion
- A scroll-progress rail tracks reading position beneath the sticky navigation/control bars.
- The Overview hero layers a pointer light, numeral/crease ornament, drifting fog, floating glow, and parallax over original local artwork.
- Performance's sticky match-story panel switches between innings tempo, batting impact, and bowling control as narrative steps enter view.
- Route changes use a soft portal/fade transition and update URL, title, and navigation. Card reveals and bar fills are restrained and data-led.
- The optional cinematic intro retains its blurred dark scrim, framed 16:9 stage, painted artwork reveal, live score HUD, close control, and route into Scorecard.
- `/assets/scorelab-immersive-arena.jpg` is original local artwork served by the C server; no external image/CDN request is needed.
- Motion uses embedded CSS/JS only: slow floodlight sweeps, moving pitch rings, pointer light, scroll drift, and a low-density ambient particle canvas. The canvas pauses in background tabs; animations stop for reduced-motion preferences.

## Accessibility
- Semantic sections, table headers, visible focus states, form labels, live-region assistant output, keyboard Escape to close dialogs, descriptive button names, and non-color values.
- Route navigation uses real links and updates browser history; mobile labels remain visible and controls remain touch-sized.
