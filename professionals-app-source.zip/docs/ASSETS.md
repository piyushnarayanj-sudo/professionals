# Asset credits

## User-supplied stadium background photographs
The following five images were supplied by the user and converted to optimized local WebP files for use across the scrolling site. They are used as section backgrounds and in photo carousels; they are decorative still images, not a live-score/video feed. The Sign-In intro uses the three largest images—sunset, futuristic arena, and wide fireworks—for its short, high-clarity sequence; stage three retains the aerial video.

- `match-arena-sunset.webp` — from `image-1.png` (800×533)
- `match-arena-aerial.webp` — from `image-2.png` (335×597)
- `match-arena-futuristic.webp` — from `image-3.png` (736×736)
- `match-arena-fireworks-wide.webp` — from `image-4.png` (800×449)
- `match-arena-fireworks-field.webp` — from `image-5.png` (327×480)

Copies are stored in `professionals-vercel-app/assets/`, `/home/user/assets/`, and `/home/user/visual-preview/assets/`. The C server whitelists each route and returns `Content-Type: image/webp`; the local unit test exercises all five endpoints.

## Sign-In background video — stages 1 and 2
- Original clip: “Cricket Stadium at Night” by Bahadur Nirankari, Pexels: https://www.pexels.com/video/cricket-stadium-at-night-11755921/
- Direct source: https://videos.pexels.com/video-files/11755921/11755921-uhd_2732_1440_60fps.mp4
- The local asset is a silent, muted, 27-second 1280×674 H.264 loop with a crossfaded seam. Poster extracted from the source.
- Local files: `professionals-vercel-app/assets/signin-cricket-loop.mp4` and `professionals-vercel-app/assets/signin-cricket-poster.jpg`.

## Sign-In aerial drone video — stage 3
- Original clip: “Aerial Night View of Cricket Stadium” by Gokuldham Nar, Pexels: https://www.pexels.com/video/aerial-night-view-of-cricket-stadium-32136468/
- Direct source: https://videos.pexels.com/video-files/32136468/13701844_2560_1440_60fps.mp4
- The local asset is a silent, muted, 14-second 1280×720 H.264 loop at 24 fps. Its final frames are blended into the opening frames; a still poster provides the fallback.
- Local files: `professionals-vercel-app/assets/signin-drone-loop.mp4` and `professionals-vercel-app/assets/signin-drone-poster.jpg`.

Both clips are from Pexels. The Pexels license allows free use and modification on websites/apps; attribution is not required, though source credits are recorded here: https://www.pexels.com/license/.
