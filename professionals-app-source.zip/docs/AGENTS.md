# Agent design — Professionals

## Agent 1: Match Analyst
**Purpose:** Explain the current scorecard and answer focused cricket-stat questions.

**Inputs:** A scorer's question plus a read-only snapshot from `/api/state`/PostgreSQL.

**Local tools:** Calculate total runs, overs, run rate, batting strike rates, top scorer, boundary leaders, leading wickets, and economy leaders. Current local implementation routes common intents (run rate, overs, wickets, economy, fours, sixes, top scorer, summary) to deterministic answers.

**Optional external mode:** If `AI_API_KEY` exists, server sends the question and current scorecard context to an OpenAI-compatible Chat Completions API using libcurl. Configure `AI_API_URL` and `AI_MODEL` as needed. If the call errors or times out, local analysis is used.

**Guardrails:** Use only the supplied scorecard; state when data is missing; never invent match events; no betting advice; never reveal the API key; no autonomous score writes.

## Agent 2: Scorecard Data Guard
**Purpose:** Keep saved figures within the rules the current data model supports.

**Checks:** Whole non-negative numbers, max roster size 100, name limits, balls faced not lower than recorded scoring shots, legal-ball limits, prepared SQL writes, and safe zero-denominator handling.

**Authority:** The C API is the sole write path. The assistant cannot modify a player's score; the scorer confirms all edits.

## Handoff/workflow
1. Frontend sends a user question to `POST /api/assistant`.
2. Server obtains a fresh, read-only scorecard snapshot.
3. If external AI is configured, send the minimized context server-to-server; otherwise route to local intent analysis.
4. Return answer and mode; UI labels whether local or external mode answered.

## Current limitation
The local analyst is deterministic, not a generative model. It works without credentials and gives verifiable scorecard answers. External AI is optional and requires a user-supplied server-side key.
