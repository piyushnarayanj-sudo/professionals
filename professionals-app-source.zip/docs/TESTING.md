# Testing and QA

## Deployment and CI preparation (2026-10-25)
- Added `.github/workflows/ci.yml` to build the C backend, run C tests, and check frontend HTML/reduced-motion/inline-JavaScript integrity on pushes and pull requests. Added `tests/check_frontend.py` for the static frontend checks.
- Local verification passed: `make -B`, `make test`, `python3 tests/check_frontend.py index.html`, and GitHub Actions YAML parsing. Generated binaries were cleaned.
- No GitHub repository/remote URL was supplied, and Netlify, Railway, GitHub, and Antigravity integrations/CLIs are unavailable in this session. CI is prepared locally but is not active on GitHub. No Netlify/Railway configuration or deployment was created.
- Production deployment remains blocked until app/API authentication is implemented and verified. Follow the standing rollout requirement: migrate and exercise the API against a separate free Neon Preview branch before considering Production. Never put deployment credentials in chat.

## Performance readability and motion follow-up (2026-10-25)
- Increased contrast on Performance by darkening its wallpaper overlay and adding opaque glass panels behind the chapter copy and benchmark heading. Brightened text, enlarged supporting copy and chart labels, and strengthened story/metric text contrast.
- Added staggered page/section entrances, story-card sheen, number and marker pops, a moving timeline accent, animated progress/chart bars, benchmark-card and record-card reveals, and responsive button/hover feedback. Effects use transform/opacity where possible; reduced-motion mode disables the added animations and wallpaper drift.
- Inline JavaScript/static checks passed; root/app/preview HTML copies are synchronized at SHA-1 `2de462602309fea26e662b47ed88a9f514415473`. The frontend patch and compressed artifact were regenerated and strictly verified from the recorded baseline.
- The refreshed static preview returned HTTP 200 for `/`, `/overview`, `/signin`, `/performance`, `/scorecard`, `/history`, `/analyst`, all five supplied WebPs, and the Sign-In videos/posters; `/api/state` remains the expected static-only 503. No browser-based visual review was available, so final perceived contrast, crop, motion pacing, and responsive layout should be checked in the preview. No deployment or database changes were made.

## Page separation follow-up — independent routes and wallpapers (2026-10-25)
- Replaced the continuous all-sections layout with route-exclusive feature pages. `/` still opens the visual-only Sign-In splash; guest entry and the Overview nav now use `/overview`, so Overview can be opened and refreshed as its own page. Performance, Scorecard, History, and Analyst remain on their own direct routes.
- Each feature page has its own supplied-arena wallpaper with subtle scroll parallax; inactive views are hidden and only the active route is rendered. Reduced-motion mode disables wallpaper drift. Added `/overview` and `/overview/` to the C HTML route whitelist and static-preview routes.
- `make -B` and `make test` passed; the C socket-pair unit test now exercises both `/overview` and `/overview/` index routes in addition to existing settings and image-route tests. Inline JavaScript and static checks passed: 140 unique IDs, six page views, root Sign-In, separate `/overview`, active-only display rules, five distinct page wallpapers, and parallax/reduced-motion handling.
- Root, app-bundle, and visual-preview HTML are byte-identical at SHA-1 `95452ee1bb178d90339a25e0a246bf78bf027072`. The regenerated frontend patch applies from baseline SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f` with `--fuzz=0`; the compressed artifact decodes exactly.
- Refreshed preview returned HTTP 200 for `/`, `/overview`, `/overview/`, `/signin`, `/performance`, `/scorecard`, `/history`, `/analyst`, all five user-supplied WebPs, both Sign-In videos, and both posters. `/api/state` returned the expected static-preview-only 503.
- No database behavior changed. Browser-level route transitions, page isolation, wallpaper rendering/parallax, responsive behavior, and reduced-motion visuals still require human review; no deployment was made.

## Clarity follow-up — Sign-In imagery (2026-10-25)
- Responded to the report that Sign-In backgrounds looked unclear: the Sign-In photo sequence now uses the three highest-resolution supplied stills (sunset, futuristic arena, wide fireworks), with reduced darkening and near-full photo opacity. The three crossfades are timed across the opening 8-second visual sequence; stage three switches to the sharper existing drone video.
- Restored the extracted cricket/drone video posters. Reduced-motion mode remains static and uses the drone poster as a fallback on the drone scene; videos remain muted/inline and are paused when hidden or when motion/data-saving preferences require it.
- Rechecked inline JavaScript (`node --check`), unique IDs, root Sign-In routing, all five Overview photos, the three Sign-In photos and static drone fallback, and referenced image files. Root, app-bundle, and visual-preview HTML are byte-identical at SHA-1 `85d9799acb77574e85767fbde011052ec6f30ca6`. The regenerated frontend-only patch reapplies from baseline SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f` with `--fuzz=0`; the compressed base64 artifact decodes byte-for-byte to the patch.
- Refreshed static-preview checks returned HTTP 200 for `/`, `/signin`, `/performance`, `/scorecard`, `/history`, `/analyst`, all five supplied WebPs, both Sign-In videos, and both posters; `/api/state` returned the expected static-preview-only HTTP 503. The C files were unchanged, so backend build/unit tests were not rerun in this HTML-only follow-up.
- **Still needs browser review:** no browser automation was available to assess actual perceived sharpness, cropping, crossfade timing, reduced-motion display, responsiveness, autoplay, or touch/keyboard interactions. The photos are still images with motion/crossfades, not live footage. No deployment or database connection was made.

## Current iteration checks — supplied backgrounds and scrolling site (2026-10-24)
- Converted the five user-supplied PNGs to optimized WebP backgrounds; the five files total 284,138 bytes. Replaced legacy background references in the HTML; a static search found zero old background asset paths.
- The root URL now opens a full-screen visual-only Sign-In splash with the existing stadium/drone videos layered with the supplied photo sequence. The guest form reveals the five main sections as one continuous scroll page; it does not authenticate or protect direct routes/API access. Sticky section links scroll to the target, and a scroll spy updates the active section. Overview and Sign-In photos crossfade with subtle pan/zoom; this is still-image motion, not real-time imagery. `prefers-reduced-motion` uses static imagery.
- `make -B` and `make test` passed; C build had no warnings. The C socket-pair unit test exercised all five new WebP routes and verified `image/webp` responses. Inline JavaScript passed `node --check`. Static inspection found 140 unique IDs, five main section links, six page sections, and all five image assets present.
- Root, app-bundle, and visual-preview HTML files are byte-identical at SHA-1 `85d9799acb77574e85767fbde011052ec6f30ca6`. The frontend-only patch applies to the recorded old HTML baseline with `--fuzz=0`; compression and exact output were verified. The patch does not package the user images, C backend, database migration, or deployment.
- Local preview returned HTTP 200 for `/`, `/signin`, `/performance`, `/scorecard`, `/history`, `/analyst`, all five supplied WebP images, and both Sign-In video loops. `/api/state` returns the expected static-preview HTTP 503; no C API or database is connected.
- No browser automation was available. Scroll behavior, visual crop/focus, keyboard/touch interaction, responsive QA, and actual motion playback still need human browser review. No database or Production deployment was attempted; the owner reports the previous Vercel project was deleted.

## Previous iteration checks — shared match metadata (2026-10-24)
- `make -B` passed the C11 backend build with `-Wall -Wextra -Wpedantic` and no compiler warnings.
- `make test` passed C-level validation coverage for trimmed names, 60-code-point bounds, escaped quotes, Unicode escapes, control characters, batting-team tokens, zero/overflowing versions, `INT_MAX`, and JSON quote/backslash encoding.
- Inline JavaScript passed `node --check`. Static HTML inspection found 140 unique IDs, preserved all five main navigation links plus `/signin`, and found each new metadata control ID exactly once.
- At the metadata-only iteration, root, app-bundle, and visual-preview HTML were byte-identical at SHA-1 `c36f1ef44553c800dc0ee748f5e6487a2de40b27`. The frontend-only patch then applied from baseline SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f` with `--fuzz=0` and reproduced that iteration's HTML; it did not verify the C backend/database migration or deployment.
- The static preview returned HTTP 200 for the five main routes plus `/signin` and the four Sign-In media assets; `/api/state` returned the intentionally unavailable static-preview HTTP 503. This is route/asset validation only, not API/database testing.
- Source implements team settings as shared metadata, version-checks writes to avoid silent stale overwrite, leaves the C scoring formulas untouched, and stores the selected labels in new history snapshots. Existing history rows receive legacy-safe defaults in an idempotent schema update.
- **Not database verified:** no local PostgreSQL client/server or Docker was available. The new `match_settings` DDL, existing-history column migration, `PUT` transaction behavior, `GET /api/state`, archive consistency, and reset behavior have not been exercised against PostgreSQL. Do not deploy until those checks pass against the separate free Neon Preview branch.
- **Not browser verified:** Playwright/browser binaries remain unavailable. The modal, keyboard/focus behavior, XSS rendering, responsive layout, and synchronization across pages/tabs need a browser pass. Static syntax/ID checks are not browser QA.
- No load test was run: **0 MiroFish agents, 0 concurrent HTTP clients**. No RPS, latency, error, CPU, memory, or database metrics exist. No live-score provider, active-session counter, or production deployment was added.

## Current iteration checks — Sign-In stage-three drone scene (2026-10-23)
- Root, app, and static-preview HTML copies are synchronized at SHA-1 `685176fddfa46428abf833c6909e4717ee57fe6c`; inline JavaScript passes `node --check`.
- The Sign-In story uses the existing stadium video for stages 1–2 and switches to a short aerial cricket-stadium drone loop for stage 3. The guest-entry form remains immediately usable; reduced-motion, Save-Data, and hidden-tab states pause both videos and retain the relevant poster fallback.
- Main Sign-In asset: silent H.264, 1280×674, 24 fps, 27 seconds, 2,299,563 bytes; OpenCV decoded all 648 frames and measured a 3.18/255 first/last-frame mean pixel delta. Stage-three drone asset: silent H.264, 1280×720, 24 fps, 14 seconds, 879,616 bytes; all 336 frames decode and first/last-frame mean pixel delta is 6.07/255. Drone poster: 80,901-byte JPEG.
- At the 2026-10-23 Sign-In iteration, the Overview used `/assets/stadium-sunset.jpg` and its background drift, pointer, and scroll motion were disabled; that artwork has since been replaced by the user-supplied image set.
- Both videos and both poster routes are whitelisted by the C server. `make -B` passed cleanly; inline JavaScript passes `node --check`. A focused C socket-pair test verified the drone MP4 route serves an exact 64-byte `206` range response and the drone JPEG poster route serves the expected `200 image/jpeg` response. Full Production patch simulation applied with `--fuzz=0`, passed the guard/syntax/build checks, and reproduced the current HTML exactly. Docker itself is unavailable locally.
- Pexels source and license notes are in `docs/ASSETS.md`.

## Earlier browser verification — prior Sign-In motion iteration
These Chromium/Playwright checks were completed before replacing the CSS-only Sign-In scene with the current video. They are useful regression history, but do not verify the current video playback or the current Overview still artwork.
- Chromium used an isolated loopback static preview with Playwright-intercepted mock API responses. No Production score/history writes were made.
- The earlier CSS loop configuration `?loop=18` computed to 18 seconds; invalid values clamped to 15 and 30. The form remained visible and usable. Earlier reduced-motion mode kept the scene static and the form/button visible.
- Sign-In made zero API requests while idle for 10.5 seconds. Completing guest entry produced one state, one History, and one agents request, with no unnecessary Analyst request.
- Direct `/history` loaded exactly one state, one History, and one agents request. Direct `/analyst` additionally made one briefing request. All five app routes, direct navigation, browser back/forward, and Performance story scrolling (tempo, batting, bowling) were exercised.
- A 36-case route/viewport sweep covered 1440×900, 1024×768, 768×1024, 390×844, 320×740, and 320×640. No horizontal overflow was found. The Sign-In submit button was in view at 320×640; the very short page can scroll to its footer.
- Effective zoom-sized viewports (1024×640, 853×533, 640×400) had no horizontal overflow. At the smallest size the Sign-In form remains scroll-accessible.
- On an unchanged Overview poll, a MutationObserver recorded zero mutations inside Overview and both chart roots. The unchanged Performance poll caused zero chart mutations and zero row entrance animations.
- Simulated changed score data updated the Overview and chart immediately without replaying row entrance motion. A delayed-state test produced one fetch for two overlapping manual refreshes. A mocked batter-add flow during a pending read aborted the stale read, kept maximum concurrent state reads at one, and updated the scorecard. These were UI/API-contract simulations, not writes to the C server.
- Warm Overview RAF sample: 4 seconds, 241 intervals, average 16.67 ms, p95 16.7 ms, maximum 16.8 ms. This is sandbox-sensitive, not a real-device benchmark. The prior bounded fireworks RAF activity stopped after its finite flourish.
- Browser console checks reported no errors or warnings during those earlier flows.

## Limits and deployment status
- No browser QA was run on the current Sign-In stage-three drone edit: Playwright CLI, browser binaries, Python Playwright, and Selenium were unavailable. The videos decode and the C media routes are tested, but browser autoplay/switching, reduced-motion poster behavior, responsive visuals, and page interactions need a browser pass. The visual-only preview is served by `visual-preview-server.py`; it serves `/` and app routes from `visual-preview/` and deliberately returns 503 for `/api/` without a C API/database.
- The earlier browser API calls were mocked. The app was not connected to a running C server or database for those UI flows; no live CRUD/archive operation was performed in this iteration.
- The C server now whitelists the poster and video routes. The video handler supports single byte ranges (including open-ended and suffix forms) and returns 416 for unsatisfiable/multiple ranges. C build and focused range tests pass; a full live database-backed server smoke test was not run for these visual edits.
- No current Production deployment is confirmed. The owner reports the previous Vercel project was deleted; a replacement has not been created. The last recorded pre-deletion HTML baseline was SHA-1 `137ce859934cc824b25afe2d6ae26692e6dadc6f`, but the old URL's current availability is unverified. The Vercel connector has denied project/deployment reads; no deployment was attempted for the scrolling/image refresh.
- At the 2026-10-23 Sign-In iteration, the then-current deployment patch simulation completed locally, but Docker itself was unavailable. The historical HTML/C hashes were `685176fddfa46428abf833c6909e4717ee57fe6c` / `3c6d6789727e2c124612b2a7e8e477a19503b010`; they predate the 2026-10-24 team-settings edits and are not current hashes.
- The earlier RAF figures are Chromium sandbox measurements only; physical mobile/GPU performance remains unverified.

## Manual browser checklist
1. Open `/` on desktop, tablet, and narrow mobile. Confirm the visual-only Sign-In splash appears; guest entry opens Overview at `/overview`; direct `/overview` reloads into Overview rather than the splash.
2. Visit `/overview`, `/performance`, `/scorecard`, `/history`, and `/analyst`. Verify only the selected feature page appears, each route has its intended wallpaper, nav clicks switch pages, browser back/forward works, and long pages scroll without clipping.
3. Scroll within each feature page and check the wallpaper’s subtle parallax, readable text, sticky navigation, and per-page progress. Ensure scrolling does not change to another route.
3. Test the Sign-In video/photo layering: stages 1–2 use the stadium loop, stage 3 switches to the aerial scene with the supplied photo, hidden-tab and Save-Data states pause video, and no API auth is implied.
4. Enable reduced motion and verify image movement and smooth scrolling stop while all content stays usable. Test desktop, tablet, mobile, zoomed, and short viewports; check overflow, keyboard focus, modal behavior, console, network, and error states.
5. Add a batter with nonzero counts; verify preview, total, strike rate, chart bar, and record cards.
6. Add a bowler with `4.2`; verify it displays as `4.2` and economy uses 26 legal balls.
7. Ask the analyst for top scorer/run rate/economy; compare responses to saved figures.
8. Edit and delete a row; verify charts and summary update.
9. Archive the live scorecard; verify the History page shows the score and leaders. Reset live data and confirm the saved snapshot remains.
10. Load demo data, reset it, and refresh the page; verify persistence and empty states.
11. Open two tabs; edit one and confirm the other refreshes within the polling interval.
12. Disable network/API and verify the offline status is understandable.
13. If an external AI key is configured, test success, timeout, invalid key, and local fallback without exposing the key.

## Formula fixtures
- Batter: 1 one, 1 two, 1 four, 1 six => 13 runs. With 10 balls, SR = 130.00.
- Bowler: 17 conceded from 26 legal balls (4.2 overs) => economy = 3.92.
- Zero balls => rate is null/dash, never division by zero.
