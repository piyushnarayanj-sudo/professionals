/*
 * Professionals cricket scorecard — C HTTP server + PostgreSQL backend.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -o scorecard_server server.c -lpq -lcurl -pthread
 */
#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <curl/curl.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <postgresql/libpq-fe.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define DEFAULT_PORT 8000
#define MAX_ROSTER 100
#define MAX_NAME_BYTES 240
#define MAX_REQUEST_BODY 100000
#define REQUEST_BUFFER_SIZE 132000
#define MAX_OVERS_BALLS 10000

static char document_root[1024] = ".";
static int listen_fd = -1;
static volatile sig_atomic_t keep_running = 1;

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
} StringBuffer;

typedef struct {
    int64_t id;
    char name[MAX_NAME_BYTES + 1];
    int ones, twos, threes, fours, sixes, balls;
    int runs;
    double strike_rate;
} Batter;

typedef struct {
    int64_t id;
    char name[MAX_NAME_BYTES + 1];
    int runs_conceded, legal_balls, wickets;
    char overs[24];
    double economy;
} Bowler;

typedef struct {
    int socket_fd;
} ClientArgs;

typedef struct {
    char name[MAX_NAME_BYTES + 1];
    int ones, twos, threes, fours, sixes, balls;
} BatterInput;

typedef struct {
    char name[MAX_NAME_BYTES + 1];
    int runs_conceded, legal_balls, wickets;
} BowlerInput;

typedef struct {
    char team_a_name[MAX_NAME_BYTES + 1];
    char team_b_name[MAX_NAME_BYTES + 1];
    int batting_team; /* 0 = team_a, 1 = team_b */
    int expected_version;
} MatchSettingsInput;

typedef struct {
    char team_a_name[MAX_NAME_BYTES + 1];
    char team_b_name[MAX_NAME_BYTES + 1];
    int batting_team; /* 0 = team_a, 1 = team_b */
    int version;
} MatchSettings;

static void string_buffer_init(StringBuffer *buffer) {
    buffer->capacity = 1024;
    buffer->length = 0;
    buffer->data = malloc(buffer->capacity);
    if (!buffer->data) {
        fprintf(stderr, "Out of memory\n");
        exit(EXIT_FAILURE);
    }
    buffer->data[0] = '\0';
}

static void string_buffer_reserve(StringBuffer *buffer, size_t additional) {
    size_t required = buffer->length + additional + 1;
    if (required <= buffer->capacity) return;
    size_t capacity = buffer->capacity;
    while (capacity < required) capacity *= 2;
    char *grown = realloc(buffer->data, capacity);
    if (!grown) {
        free(buffer->data);
        fprintf(stderr, "Out of memory\n");
        exit(EXIT_FAILURE);
    }
    buffer->data = grown;
    buffer->capacity = capacity;
}

static void string_buffer_append_n(StringBuffer *buffer, const char *text, size_t length) {
    string_buffer_reserve(buffer, length);
    memcpy(buffer->data + buffer->length, text, length);
    buffer->length += length;
    buffer->data[buffer->length] = '\0';
}

static void string_buffer_append(StringBuffer *buffer, const char *text) {
    string_buffer_append_n(buffer, text, strlen(text));
}

static void string_buffer_appendf(StringBuffer *buffer, const char *format, ...) {
    va_list args, copy;
    va_start(args, format);
    va_copy(copy, args);
    int required = vsnprintf(NULL, 0, format, copy);
    va_end(copy);
    if (required < 0) {
        va_end(args);
        return;
    }
    string_buffer_reserve(buffer, (size_t)required);
    vsnprintf(buffer->data + buffer->length, buffer->capacity - buffer->length, format, args);
    buffer->length += (size_t)required;
    va_end(args);
}

static void string_buffer_json_string(StringBuffer *buffer, const char *text) {
    const unsigned char *cursor = (const unsigned char *)text;
    string_buffer_append(buffer, "\"");
    while (*cursor) {
        unsigned char ch = *cursor++;
        switch (ch) {
            case '"': string_buffer_append(buffer, "\\\""); break;
            case '\\': string_buffer_append(buffer, "\\\\"); break;
            case '\b': string_buffer_append(buffer, "\\b"); break;
            case '\f': string_buffer_append(buffer, "\\f"); break;
            case '\n': string_buffer_append(buffer, "\\n"); break;
            case '\r': string_buffer_append(buffer, "\\r"); break;
            case '\t': string_buffer_append(buffer, "\\t"); break;
            default:
                if (ch < 0x20) string_buffer_appendf(buffer, "\\u%04x", ch);
                else string_buffer_append_n(buffer, (const char *)&ch, 1);
        }
    }
    string_buffer_append(buffer, "\"");
}

static int send_all(int socket_fd, const void *data, size_t length) {
    const char *cursor = data;
    while (length > 0) {
        ssize_t sent = send(socket_fd, cursor, length, 0);
        if (sent < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        cursor += sent;
        length -= (size_t)sent;
    }
    return 0;
}

static const char *status_text(int status) {
    switch (status) {
        case 200: return "OK";
        case 201: return "Created";
        case 204: return "No Content";
        case 206: return "Partial Content";
        case 400: return "Bad Request";
        case 404: return "Not Found";
        case 409: return "Conflict";
        case 405: return "Method Not Allowed";
        case 413: return "Payload Too Large";
        case 416: return "Range Not Satisfiable";
        case 500: return "Internal Server Error";
        case 503: return "Service Unavailable";
        default: return "OK";
    }
}

static void send_response(int socket_fd, int status, const char *content_type, const void *body, size_t length) {
    char header[512];
    int header_length = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Cache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "Connection: close\r\n\r\n",
        status, status_text(status), content_type, length);
    if (header_length > 0) {
        if (send_all(socket_fd, header, (size_t)header_length) == 0 && length > 0) {
            send_all(socket_fd, body, length);
        }
    }
}

static void send_json(int socket_fd, int status, const char *json) {
    send_response(socket_fd, status, "application/json; charset=utf-8", json, strlen(json));
}

static void send_error(int socket_fd, int status, const char *message) {
    StringBuffer response;
    string_buffer_init(&response);
    string_buffer_append(&response, "{\"error\":");
    string_buffer_json_string(&response, message);
    string_buffer_append(&response, "}");
    send_json(socket_fd, status, response.data);
    free(response.data);
}

static int utf8_append(char *output, size_t capacity, size_t *used, uint32_t codepoint) {
    unsigned char bytes[4];
    size_t count;
    if (codepoint == 0 || codepoint > 0x10FFFF || (codepoint >= 0xD800 && codepoint <= 0xDFFF)) return 0;
    if (codepoint <= 0x7F) {
        bytes[0] = (unsigned char)codepoint; count = 1;
    } else if (codepoint <= 0x7FF) {
        bytes[0] = (unsigned char)(0xC0 | (codepoint >> 6));
        bytes[1] = (unsigned char)(0x80 | (codepoint & 0x3F)); count = 2;
    } else if (codepoint <= 0xFFFF) {
        bytes[0] = (unsigned char)(0xE0 | (codepoint >> 12));
        bytes[1] = (unsigned char)(0x80 | ((codepoint >> 6) & 0x3F));
        bytes[2] = (unsigned char)(0x80 | (codepoint & 0x3F)); count = 3;
    } else {
        bytes[0] = (unsigned char)(0xF0 | (codepoint >> 18));
        bytes[1] = (unsigned char)(0x80 | ((codepoint >> 12) & 0x3F));
        bytes[2] = (unsigned char)(0x80 | ((codepoint >> 6) & 0x3F));
        bytes[3] = (unsigned char)(0x80 | (codepoint & 0x3F)); count = 4;
    }
    if (*used + count >= capacity) return 0;
    memcpy(output + *used, bytes, count);
    *used += count;
    return 1;
}

static int hex4(const char *text, uint32_t *value) {
    uint32_t result = 0;
    for (int i = 0; i < 4; i++) {
        unsigned char ch = (unsigned char)text[i];
        int digit;
        if (ch >= '0' && ch <= '9') digit = ch - '0';
        else if (ch >= 'a' && ch <= 'f') digit = ch - 'a' + 10;
        else if (ch >= 'A' && ch <= 'F') digit = ch - 'A' + 10;
        else return 0;
        result = (result << 4) | (uint32_t)digit;
    }
    *value = result;
    return 1;
}

static const char *skip_whitespace(const char *cursor) {
    while (*cursor && isspace((unsigned char)*cursor)) cursor++;
    return cursor;
}

static int parse_json_string(const char **cursor, char *output, size_t capacity) {
    const char *p = *cursor;
    if (*p != '"') return 0;
    p++;
    size_t used = 0;
    while (*p && *p != '"') {
        unsigned char ch = (unsigned char)*p++;
        if (ch < 0x20) return 0;
        if (ch == '\\') {
            char escaped = *p++;
            switch (escaped) {
                case '"': ch = '"'; break;
                case '\\': ch = '\\'; break;
                case '/': ch = '/'; break;
                case 'b': ch = '\b'; break;
                case 'f': ch = '\f'; break;
                case 'n': ch = '\n'; break;
                case 'r': ch = '\r'; break;
                case 't': ch = '\t'; break;
                case 'u': {
                    uint32_t codepoint;
                    if (strlen(p) < 4 || !hex4(p, &codepoint)) return 0;
                    p += 4;
                    if (codepoint >= 0xD800 && codepoint <= 0xDBFF) {
                        if (p[0] != '\\' || p[1] != 'u' || strlen(p + 2) < 4) return 0;
                        uint32_t low;
                        if (!hex4(p + 2, &low) || low < 0xDC00 || low > 0xDFFF) return 0;
                        p += 6;
                        codepoint = 0x10000 + ((codepoint - 0xD800) << 10) + (low - 0xDC00);
                    }
                    if (!utf8_append(output, capacity, &used, codepoint)) return 0;
                    continue;
                }
                default: return 0;
            }
            if (ch < 0x20) return 0;
        }
        if (used + 1 >= capacity) return 0;
        output[used++] = (char)ch;
    }
    if (*p != '"') return 0;
    output[used] = '\0';
    *cursor = p + 1;
    return 1;
}

static int skip_json_value(const char **cursor) {
    const char *p = skip_whitespace(*cursor);
    if (*p == '"') {
        p++;
        while (*p) {
            if (*p == '\\') { if (p[1] == '\0') return 0; p += 2; continue; }
            if (*p++ == '"') { *cursor = p; return 1; }
        }
        return 0;
    }
    if (*p == '{' || *p == '[') {
        char stack[32];
        size_t depth = 0;
        int in_string = 0, escaped = 0;
        stack[depth++] = (*p == '{') ? '}' : ']';
        p++;
        while (*p && depth > 0) {
            char ch = *p++;
            if (in_string) {
                if (escaped) escaped = 0;
                else if (ch == '\\') escaped = 1;
                else if (ch == '"') in_string = 0;
                continue;
            }
            if (ch == '"') in_string = 1;
            else if (ch == '{' || ch == '[') {
                if (depth >= sizeof(stack)) return 0;
                stack[depth++] = ch == '{' ? '}' : ']';
            } else if (ch == '}' || ch == ']') {
                if (stack[depth - 1] != ch) return 0;
                depth--;
            }
        }
        if (depth != 0 || in_string) return 0;
        *cursor = p;
        return 1;
    }
    while (*p && *p != ',' && *p != '}' && *p != ']' && !isspace((unsigned char)*p)) p++;
    if (p == *cursor) return 0;
    *cursor = p;
    return 1;
}

/* Find one flat JSON object property and decode it as a string. */
static int json_get_string(const char *json, const char *wanted, char *output, size_t capacity) {
    const char *p = skip_whitespace(json);
    if (*p++ != '{') return 0;
    for (;;) {
        p = skip_whitespace(p);
        if (*p == '}') return 0;
        char key[128];
        if (!parse_json_string(&p, key, sizeof(key))) return 0;
        p = skip_whitespace(p);
        if (*p++ != ':') return 0;
        p = skip_whitespace(p);
        if (strcmp(key, wanted) == 0) return parse_json_string(&p, output, capacity);
        if (!skip_json_value(&p)) return 0;
        p = skip_whitespace(p);
        if (*p == ',') { p++; continue; }
        if (*p == '}') return 0;
        return 0;
    }
}

/* Find one flat JSON object property and parse a non-negative integer. */
static int json_get_integer(const char *json, const char *wanted, int maximum, int *output) {
    const char *p = skip_whitespace(json);
    if (*p++ != '{') return 0;
    for (;;) {
        p = skip_whitespace(p);
        if (*p == '}') return 0;
        char key[128];
        if (!parse_json_string(&p, key, sizeof(key))) return 0;
        p = skip_whitespace(p);
        if (*p++ != ':') return 0;
        p = skip_whitespace(p);
        if (strcmp(key, wanted) == 0) {
            if (!isdigit((unsigned char)*p)) return 0;
            long value = 0;
            while (isdigit((unsigned char)*p)) {
                int digit = *p++ - '0';
                if (digit > maximum || value > (maximum - digit) / 10) return 0;
                value = value * 10 + digit;
            }
            p = skip_whitespace(p);
            if (*p != ',' && *p != '}' && *p != '\0') return 0;
            *output = (int)value;
            return 1;
        }
        if (!skip_json_value(&p)) return 0;
        p = skip_whitespace(p);
        if (*p == ',') { p++; continue; }
        if (*p == '}') return 0;
        return 0;
    }
}

static int valid_name(const char *name, char *error, size_t error_capacity) {
    size_t length = strlen(name);
    if (length == 0) {
        snprintf(error, error_capacity, "Enter a player name.");
        return 0;
    }
    if (length > MAX_NAME_BYTES) {
        snprintf(error, error_capacity, "Player names must be 60 characters or fewer.");
        return 0;
    }
    size_t characters = 0;
    for (size_t i = 0; i < length; i++) {
        unsigned char ch = (unsigned char)name[i];
        if (ch < 0x20 || ch == 0x7f) {
            snprintf(error, error_capacity, "Player names cannot contain control characters.");
            return 0;
        }
        if ((ch & 0xC0) != 0x80 && ++characters > 60) {
            snprintf(error, error_capacity, "Player names must be 60 characters or fewer.");
            return 0;
        }
    }
    return 1;
}

static void trim_name(char *name) {
    size_t length = strlen(name);
    size_t start = 0;
    while (start < length && isspace((unsigned char)name[start])) start++;
    while (length > start && isspace((unsigned char)name[length - 1])) length--;
    if (start > 0) memmove(name, name + start, length - start);
    name[length - start] = '\0';
}

static int parse_batter_input(const char *body, BatterInput *input, char *error, size_t error_capacity) {
    if (!json_get_string(body, "name", input->name, sizeof(input->name))) {
        snprintf(error, error_capacity, "Enter a player name."); return 0;
    }
    trim_name(input->name);
    if (!valid_name(input->name, error, error_capacity)) return 0;
    if (!json_get_integer(body, "ones", 10000, &input->ones) ||
        !json_get_integer(body, "twos", 10000, &input->twos) ||
        !json_get_integer(body, "threes", 10000, &input->threes) ||
        !json_get_integer(body, "fours", 10000, &input->fours) ||
        !json_get_integer(body, "sixes", 10000, &input->sixes) ||
        !json_get_integer(body, "balls", 10000, &input->balls)) {
        snprintf(error, error_capacity, "Batting counts must be whole numbers between 0 and 10,000."); return 0;
    }
    if (input->balls < input->ones + input->twos + input->threes + input->fours + input->sixes) {
        snprintf(error, error_capacity, "Balls faced cannot be fewer than the scoring shots recorded."); return 0;
    }
    return 1;
}

static int parse_bowler_input(const char *body, BowlerInput *input, char *error, size_t error_capacity) {
    if (!json_get_string(body, "name", input->name, sizeof(input->name))) {
        snprintf(error, error_capacity, "Enter a player name."); return 0;
    }
    trim_name(input->name);
    if (!valid_name(input->name, error, error_capacity)) return 0;
    if (!json_get_integer(body, "runs_conceded", 10000, &input->runs_conceded) ||
        !json_get_integer(body, "legal_balls", MAX_OVERS_BALLS, &input->legal_balls) ||
        !json_get_integer(body, "wickets", 10000, &input->wickets)) {
        snprintf(error, error_capacity, "Bowling counts must be whole numbers within the allowed range."); return 0;
    }
    return 1;
}

static int valid_team_name(const char *name, const char *label, char *error, size_t error_capacity) {
    size_t length = strlen(name);
    if (length == 0) {
        snprintf(error, error_capacity, "Enter %s's name.", label);
        return 0;
    }
    if (length > MAX_NAME_BYTES) {
        snprintf(error, error_capacity, "Team names must be 60 characters or fewer.");
        return 0;
    }
    size_t characters = 0;
    for (size_t i = 0; i < length; i++) {
        unsigned char ch = (unsigned char)name[i];
        if (ch < 0x20 || ch == 0x7f) {
            snprintf(error, error_capacity, "Team names cannot contain control characters.");
            return 0;
        }
        if ((ch & 0xC0) != 0x80 && ++characters > 60) {
            snprintf(error, error_capacity, "Team names must be 60 characters or fewer.");
            return 0;
        }
    }
    return 1;
}

static int parse_match_settings_input(const char *body, MatchSettingsInput *input,
                                      char *error, size_t error_capacity) {
    char batting_team[16] = {0};
    if (!json_get_string(body, "team_a_name", input->team_a_name, sizeof(input->team_a_name))) {
        snprintf(error, error_capacity, "Enter Team A's name."); return 0;
    }
    if (!json_get_string(body, "team_b_name", input->team_b_name, sizeof(input->team_b_name))) {
        snprintf(error, error_capacity, "Enter Team B's name."); return 0;
    }
    trim_name(input->team_a_name);
    trim_name(input->team_b_name);
    if (!valid_team_name(input->team_a_name, "Team A", error, error_capacity) ||
        !valid_team_name(input->team_b_name, "Team B", error, error_capacity)) return 0;
    if (!json_get_string(body, "batting_team", batting_team, sizeof(batting_team))) {
        snprintf(error, error_capacity, "Choose which team is batting."); return 0;
    }
    if (strcmp(batting_team, "team_a") == 0) input->batting_team = 0;
    else if (strcmp(batting_team, "team_b") == 0) input->batting_team = 1;
    else { snprintf(error, error_capacity, "Batting team must be team_a or team_b."); return 0; }
    if (!json_get_integer(body, "expected_version", INT_MAX, &input->expected_version) ||
        input->expected_version < 1) {
        snprintf(error, error_capacity, "Refresh match details before saving them."); return 0;
    }
    return 1;
}

static const char *database_connection_string(void) {
    const char *names[] = {"DATABASE_URL", "POSTGRES_URL", "POSTGRES_URL_NON_POOLING", "POSTGRES_URL_UNPOOLED", "DATABASE_URL_UNPOOLED", "NEON_DATABASE_URL"};
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
        const char *value = getenv(names[i]);
        if (value && *value) return value;
    }
    return NULL;
}

static void set_database_error(char *error, size_t error_capacity, const char *operation,
                               PGconn *database, PGresult *result) {
    if (!error || error_capacity == 0) return;
    const char *source = result ? PQresultErrorMessage(result) : (database ? PQerrorMessage(database) : NULL);
    if (!source || !*source) source = "unknown PostgreSQL error";
    char detail[192];
    size_t length = strcspn(source, "\r\n");
    if (length >= sizeof(detail)) length = sizeof(detail) - 1;
    memcpy(detail, source, length);
    detail[length] = '\0';
    snprintf(error, error_capacity, "%s: %s", operation, detail);
}

static PGresult *database_query(PGconn *database, const char *sql, int parameter_count,
                                const char *const *parameters, ExecStatusType expected_status,
                                const char *operation, char *error, size_t error_capacity) {
    PGresult *result = PQexecParams(database, sql, parameter_count, NULL, parameters, NULL, NULL, 0);
    if (!result || PQresultStatus(result) != expected_status) {
        set_database_error(error, error_capacity, operation, database, result);
        if (result) PQclear(result);
        return NULL;
    }
    return result;
}

static int database_command(PGconn *database, const char *sql, const char *operation,
                            char *error, size_t error_capacity) {
    PGresult *result = database_query(database, sql, 0, NULL, PGRES_COMMAND_OK,
                                      operation, error, error_capacity);
    if (!result) return 0;
    PQclear(result);
    return 1;
}

static void database_rollback(PGconn *database) {
    if (!database) return;
    PGresult *result = PQexec(database, "ROLLBACK");
    if (result) PQclear(result);
}

static PGconn *open_database(void) {
    const char *connection_string = database_connection_string();
    if (!connection_string) {
        fprintf(stderr, "PostgreSQL connection is not configured (set DATABASE_URL).\n");
        return NULL;
    }
    PGconn *database = PQconnectdb(connection_string);
    if (!database || PQstatus(database) != CONNECTION_OK) {
        fprintf(stderr, "PostgreSQL connection error: %s\n",
                database ? PQerrorMessage(database) : "out of memory");
        if (database) PQfinish(database);
        return NULL;
    }
    return database;
}

static int initialize_database(void) {
    static const char *schema[] = {
        "CREATE TABLE IF NOT EXISTS batsmen ("
        "id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL,"
        "ones INTEGER NOT NULL DEFAULT 0 CHECK (ones >= 0),"
        "twos INTEGER NOT NULL DEFAULT 0 CHECK (twos >= 0),"
        "threes INTEGER NOT NULL DEFAULT 0 CHECK (threes >= 0),"
        "fours INTEGER NOT NULL DEFAULT 0 CHECK (fours >= 0),"
        "sixes INTEGER NOT NULL DEFAULT 0 CHECK (sixes >= 0),"
        "balls INTEGER NOT NULL DEFAULT 0 CHECK (balls >= 0))",
        "CREATE TABLE IF NOT EXISTS bowlers ("
        "id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL,"
        "runs_conceded INTEGER NOT NULL DEFAULT 0 CHECK (runs_conceded >= 0),"
        "legal_balls INTEGER NOT NULL DEFAULT 0 CHECK (legal_balls >= 0),"
        "wickets INTEGER NOT NULL DEFAULT 0 CHECK (wickets >= 0))",
        "CREATE TABLE IF NOT EXISTS match_history ("
        "id BIGSERIAL PRIMARY KEY, match_name TEXT NOT NULL,"
        "archived_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        "runs BIGINT NOT NULL, wickets BIGINT NOT NULL, legal_balls BIGINT NOT NULL,"
        "run_rate DOUBLE PRECISION, fours BIGINT NOT NULL DEFAULT 0, sixes BIGINT NOT NULL DEFAULT 0,"
        "batter_count INTEGER NOT NULL DEFAULT 0, bowler_count INTEGER NOT NULL DEFAULT 0,"
        "top_scorer TEXT NOT NULL DEFAULT '', top_runs BIGINT NOT NULL DEFAULT 0,"
        "top_bowler TEXT NOT NULL DEFAULT '', top_wickets BIGINT NOT NULL DEFAULT 0,"
        "team_a_name TEXT NOT NULL DEFAULT 'Team A', team_b_name TEXT NOT NULL DEFAULT 'Team B',"
        "batting_team TEXT NOT NULL DEFAULT 'team_a')",
        "ALTER TABLE match_history ADD COLUMN IF NOT EXISTS team_a_name TEXT NOT NULL DEFAULT 'Team A'",
        "ALTER TABLE match_history ADD COLUMN IF NOT EXISTS team_b_name TEXT NOT NULL DEFAULT 'Team B'",
        "ALTER TABLE match_history ADD COLUMN IF NOT EXISTS batting_team TEXT NOT NULL DEFAULT 'team_a'",
        "CREATE TABLE IF NOT EXISTS match_settings ("
        "id SMALLINT PRIMARY KEY CHECK (id = 1),"
        "team_a_name TEXT NOT NULL DEFAULT 'Team A',"
        "team_b_name TEXT NOT NULL DEFAULT 'Team B',"
        "batting_team TEXT NOT NULL DEFAULT 'team_a' CHECK (batting_team IN ('team_a','team_b'))," 
        "version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),"
        "updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "INSERT INTO match_settings (id,team_a_name,team_b_name,batting_team,version) "
        "VALUES (1,'Team A','Team B','team_a',1) ON CONFLICT (id) DO NOTHING"
    };
    PGconn *database = open_database();
    if (!database) return 0;
    for (size_t i = 0; i < sizeof(schema) / sizeof(schema[0]); i++) {
        char error[256] = {0};
        if (!database_command(database, schema[i], "Could not initialize PostgreSQL schema", error, sizeof(error))) {
            fprintf(stderr, "PostgreSQL schema error: %s\n", error);
            PQfinish(database);
            return 0;
        }
    }
    PQfinish(database);
    return 1;
}

static int database_read_match_settings(PGconn *database, MatchSettings *settings,
                                        char *error, size_t error_capacity) {
    PGresult *result = database_query(database,
        "SELECT team_a_name,team_b_name,batting_team,version FROM match_settings WHERE id=1",
        0, NULL, PGRES_TUPLES_OK, "Could not load match settings", error, error_capacity);
    if (!result) return 0;
    if (PQntuples(result) != 1) {
        snprintf(error, error_capacity, "Match settings are missing from PostgreSQL.");
        PQclear(result);
        return 0;
    }
    snprintf(settings->team_a_name, sizeof(settings->team_a_name), "%s", PQgetvalue(result, 0, 0));
    snprintf(settings->team_b_name, sizeof(settings->team_b_name), "%s", PQgetvalue(result, 0, 1));
    settings->batting_team = strcmp(PQgetvalue(result, 0, 2), "team_b") == 0 ? 1 : 0;
    settings->version = (int)strtol(PQgetvalue(result, 0, 3), NULL, 10);
    PQclear(result);
    return 1;
}

static int database_update_match_settings(const MatchSettingsInput *input, int *new_version,
                                         char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return -1; }
    char version[24];
    snprintf(version, sizeof(version), "%d", input->expected_version);
    const char *batting_team = input->batting_team ? "team_b" : "team_a";
    const char *parameters[] = {input->team_a_name, input->team_b_name, batting_team, version};
    PGresult *result = database_query(database,
        "UPDATE match_settings SET team_a_name=$1,team_b_name=$2,batting_team=$3,"
        "version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND version=$4 RETURNING version",
        4, parameters, PGRES_TUPLES_OK, "Could not save match settings", error, error_capacity);
    if (!result) { PQfinish(database); return -1; }
    if (PQntuples(result) != 1) {
        PQclear(result);
        PQfinish(database);
        return 0;
    }
    *new_version = (int)strtol(PQgetvalue(result, 0, 0), NULL, 10);
    PQclear(result);
    PQfinish(database);
    return 1;
}

static int count_records(PGconn *database, const char *table, char *error, size_t error_capacity) {
    char sql[96];
    snprintf(sql, sizeof(sql), "SELECT COUNT(*) FROM %s", table);
    PGresult *result = database_query(database, sql, 0, NULL, PGRES_TUPLES_OK,
                                      "Could not count scorecard records", error, error_capacity);
    if (!result) return -1;
    int count = atoi(PQgetvalue(result, 0, 0));
    PQclear(result);
    return count;
}

static int database_insert_batter(const BatterInput *input, int64_t *new_id, char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return 0; }
    if (!database_command(database, "BEGIN", "Could not start a database transaction", error, error_capacity) ||
        !database_command(database, "LOCK TABLE batsmen IN EXCLUSIVE MODE", "Could not lock the batter roster", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    int count = count_records(database, "batsmen", error, error_capacity);
    if (count < 0) { database_rollback(database); PQfinish(database); return 0; }
    if (count >= MAX_ROSTER) {
        snprintf(error, error_capacity, "A scorecard can contain at most 100 batters.");
        database_rollback(database); PQfinish(database); return 0;
    }
    char values[6][24];
    snprintf(values[0], sizeof(values[0]), "%d", input->ones);
    snprintf(values[1], sizeof(values[1]), "%d", input->twos);
    snprintf(values[2], sizeof(values[2]), "%d", input->threes);
    snprintf(values[3], sizeof(values[3]), "%d", input->fours);
    snprintf(values[4], sizeof(values[4]), "%d", input->sixes);
    snprintf(values[5], sizeof(values[5]), "%d", input->balls);
    const char *parameters[] = {input->name, values[0], values[1], values[2], values[3], values[4], values[5]};
    PGresult *result = database_query(database,
        "INSERT INTO batsmen (name,ones,twos,threes,fours,sixes,balls) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id",
        7, parameters, PGRES_TUPLES_OK, "Could not save batter", error, error_capacity);
    if (!result || PQntuples(result) != 1) {
        if (result) PQclear(result);
        if (!error[0]) snprintf(error, error_capacity, "Could not save batter: no row was returned.");
        database_rollback(database); PQfinish(database); return 0;
    }
    *new_id = (int64_t)strtoll(PQgetvalue(result, 0, 0), NULL, 10);
    PQclear(result);
    if (!database_command(database, "COMMIT", "Could not commit batter", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    PQfinish(database);
    return 1;
}

static int database_insert_bowler(const BowlerInput *input, int64_t *new_id, char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return 0; }
    if (!database_command(database, "BEGIN", "Could not start a database transaction", error, error_capacity) ||
        !database_command(database, "LOCK TABLE bowlers IN EXCLUSIVE MODE", "Could not lock the bowler roster", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    int count = count_records(database, "bowlers", error, error_capacity);
    if (count < 0) { database_rollback(database); PQfinish(database); return 0; }
    if (count >= MAX_ROSTER) {
        snprintf(error, error_capacity, "A scorecard can contain at most 100 bowlers.");
        database_rollback(database); PQfinish(database); return 0;
    }
    char values[3][24];
    snprintf(values[0], sizeof(values[0]), "%d", input->runs_conceded);
    snprintf(values[1], sizeof(values[1]), "%d", input->legal_balls);
    snprintf(values[2], sizeof(values[2]), "%d", input->wickets);
    const char *parameters[] = {input->name, values[0], values[1], values[2]};
    PGresult *result = database_query(database,
        "INSERT INTO bowlers (name,runs_conceded,legal_balls,wickets) VALUES ($1,$2,$3,$4) RETURNING id",
        4, parameters, PGRES_TUPLES_OK, "Could not save bowler", error, error_capacity);
    if (!result || PQntuples(result) != 1) {
        if (result) PQclear(result);
        if (!error[0]) snprintf(error, error_capacity, "Could not save bowler: no row was returned.");
        database_rollback(database); PQfinish(database); return 0;
    }
    *new_id = (int64_t)strtoll(PQgetvalue(result, 0, 0), NULL, 10);
    PQclear(result);
    if (!database_command(database, "COMMIT", "Could not commit bowler", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    PQfinish(database);
    return 1;
}

static int database_update_batter(int64_t id, const BatterInput *input, char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return -1; }
    char values[7][24], id_text[32];
    snprintf(values[0], sizeof(values[0]), "%d", input->ones);
    snprintf(values[1], sizeof(values[1]), "%d", input->twos);
    snprintf(values[2], sizeof(values[2]), "%d", input->threes);
    snprintf(values[3], sizeof(values[3]), "%d", input->fours);
    snprintf(values[4], sizeof(values[4]), "%d", input->sixes);
    snprintf(values[5], sizeof(values[5]), "%d", input->balls);
    snprintf(id_text, sizeof(id_text), "%lld", (long long)id);
    const char *parameters[] = {input->name, values[0], values[1], values[2], values[3], values[4], values[5], id_text};
    PGresult *result = database_query(database,
        "UPDATE batsmen SET name=$1,ones=$2,twos=$3,threes=$4,fours=$5,sixes=$6,balls=$7 WHERE id=$8",
        8, parameters, PGRES_COMMAND_OK, "Could not update batter", error, error_capacity);
    if (!result) { PQfinish(database); return -1; }
    int changes = atoi(PQcmdTuples(result));
    PQclear(result);
    PQfinish(database);
    return changes;
}

static int database_update_bowler(int64_t id, const BowlerInput *input, char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return -1; }
    char values[3][24], id_text[32];
    snprintf(values[0], sizeof(values[0]), "%d", input->runs_conceded);
    snprintf(values[1], sizeof(values[1]), "%d", input->legal_balls);
    snprintf(values[2], sizeof(values[2]), "%d", input->wickets);
    snprintf(id_text, sizeof(id_text), "%lld", (long long)id);
    const char *parameters[] = {input->name, values[0], values[1], values[2], id_text};
    PGresult *result = database_query(database,
        "UPDATE bowlers SET name=$1,runs_conceded=$2,legal_balls=$3,wickets=$4 WHERE id=$5",
        5, parameters, PGRES_COMMAND_OK, "Could not update bowler", error, error_capacity);
    if (!result) { PQfinish(database); return -1; }
    int changes = atoi(PQcmdTuples(result));
    PQclear(result);
    PQfinish(database);
    return changes;
}

static int database_delete(const char *table, int64_t id, char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return -1; }
    char sql[96], id_text[32];
    snprintf(sql, sizeof(sql), "DELETE FROM %s WHERE id=$1", table);
    snprintf(id_text, sizeof(id_text), "%lld", (long long)id);
    const char *parameters[] = {id_text};
    PGresult *result = database_query(database, sql, 1, parameters, PGRES_COMMAND_OK,
                                      "Could not delete player", error, error_capacity);
    if (!result) { PQfinish(database); return -1; }
    int changes = atoi(PQcmdTuples(result));
    PQclear(result);
    PQfinish(database);
    return changes;
}

static int database_reset(char *error, size_t error_capacity) {
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return 0; }
    if (!database_command(database, "BEGIN", "Could not start reset transaction", error, error_capacity) ||
        !database_command(database, "TRUNCATE TABLE batsmen, bowlers RESTART IDENTITY",
                          "Could not reset scorecard", error, error_capacity) ||
        !database_command(database, "COMMIT", "Could not commit scorecard reset", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    PQfinish(database);
    return 1;
}

static int pg_int(PGresult *result, int row, int column) {
    return PQgetisnull(result, row, column) ? 0 : (int)strtol(PQgetvalue(result, row, column), NULL, 10);
}

static int64_t pg_column_int64(PGresult *result, int row, int column) {
    return PQgetisnull(result, row, column) ? 0 : (int64_t)strtoll(PQgetvalue(result, row, column), NULL, 10);
}

static void calculate_batter(Batter *player) {
    player->runs = player->ones + 2 * player->twos + 3 * player->threes + 4 * player->fours + 6 * player->sixes;
    player->strike_rate = player->balls > 0 ? (double)player->runs * 100.0 / player->balls : 0.0;
}

static void calculate_bowler(Bowler *player) {
    snprintf(player->overs, sizeof(player->overs), "%d.%d", player->legal_balls / 6, player->legal_balls % 6);
    player->economy = player->legal_balls > 0 ? (double)player->runs_conceded * 6.0 / player->legal_balls : 0.0;
}

static int load_players(Batter *batsmen, int *batter_count, Bowler *bowlers, int *bowler_count,
                        MatchSettings *match_settings, char *error, size_t error_capacity) {
    *batter_count = 0;
    *bowler_count = 0;
    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return 0; }
    PGresult *result = database_query(database,
        "SELECT id,name,ones,twos,threes,fours,sixes,balls FROM batsmen ORDER BY id",
        0, NULL, PGRES_TUPLES_OK, "Could not load batters", error, error_capacity);
    if (!result) { PQfinish(database); return 0; }
    for (int row = 0; row < PQntuples(result) && *batter_count < MAX_ROSTER; row++) {
        Batter *player = &batsmen[(*batter_count)++];
        player->id = pg_column_int64(result, row, 0);
        snprintf(player->name, sizeof(player->name), "%s", PQgetvalue(result, row, 1));
        player->ones = pg_int(result, row, 2); player->twos = pg_int(result, row, 3);
        player->threes = pg_int(result, row, 4); player->fours = pg_int(result, row, 5);
        player->sixes = pg_int(result, row, 6); player->balls = pg_int(result, row, 7);
        calculate_batter(player);
    }
    PQclear(result);
    result = database_query(database,
        "SELECT id,name,runs_conceded,legal_balls,wickets FROM bowlers ORDER BY id",
        0, NULL, PGRES_TUPLES_OK, "Could not load bowlers", error, error_capacity);
    if (!result) { PQfinish(database); return 0; }
    for (int row = 0; row < PQntuples(result) && *bowler_count < MAX_ROSTER; row++) {
        Bowler *player = &bowlers[(*bowler_count)++];
        player->id = pg_column_int64(result, row, 0);
        snprintf(player->name, sizeof(player->name), "%s", PQgetvalue(result, row, 1));
        player->runs_conceded = pg_int(result, row, 2);
        player->legal_balls = pg_int(result, row, 3);
        player->wickets = pg_int(result, row, 4);
        calculate_bowler(player);
    }
    PQclear(result);
    if (match_settings && !database_read_match_settings(database, match_settings, error, error_capacity)) {
        PQfinish(database);
        return 0;
    }
    PQfinish(database);
    return 1;
}

static int database_archive_match(const char *match_name, int64_t *new_id, char *error, size_t error_capacity) {
    Batter batsmen[MAX_ROSTER] = {0};
    Bowler bowlers[MAX_ROSTER] = {0};
    int batter_count = 0, bowler_count = 0;
    if (!load_players(batsmen, &batter_count, bowlers, &bowler_count, NULL, error, error_capacity)) return 0;
    if (batter_count == 0 && bowler_count == 0) {
        snprintf(error, error_capacity, "Add at least one batter or bowler before archiving a match.");
        return 0;
    }

    long long runs = 0, wickets = 0, legal_balls = 0, fours = 0, sixes = 0;
    int top_batter = -1, top_bowler = -1;
    for (int i = 0; i < batter_count; i++) {
        runs += batsmen[i].runs;
        fours += batsmen[i].fours;
        sixes += batsmen[i].sixes;
        if (batsmen[i].runs > 0 && (top_batter < 0 || batsmen[i].runs > batsmen[top_batter].runs)) top_batter = i;
    }
    for (int i = 0; i < bowler_count; i++) {
        wickets += bowlers[i].wickets;
        legal_balls += bowlers[i].legal_balls;
        if (bowlers[i].wickets > 0 && (top_bowler < 0 || bowlers[i].wickets > bowlers[top_bowler].wickets ||
            (bowlers[i].wickets == bowlers[top_bowler].wickets && bowlers[i].economy < bowlers[top_bowler].economy))) top_bowler = i;
    }

    PGconn *database = open_database();
    if (!database) { snprintf(error, error_capacity, "Could not connect to PostgreSQL."); return 0; }
    if (!database_command(database, "BEGIN", "Could not start an archive transaction", error, error_capacity)) {
        PQfinish(database); return 0;
    }
    PGresult *settings_result = database_query(database,
        "SELECT team_a_name,team_b_name,batting_team FROM match_settings WHERE id=1 FOR SHARE",
        0, NULL, PGRES_TUPLES_OK, "Could not read match details for the archive", error, error_capacity);
    if (!settings_result || PQntuples(settings_result) != 1) {
        if (settings_result) PQclear(settings_result);
        if (!error[0]) snprintf(error, error_capacity, "Match settings are missing from PostgreSQL.");
        database_rollback(database); PQfinish(database); return 0;
    }
    char team_a_name[MAX_NAME_BYTES + 1], team_b_name[MAX_NAME_BYTES + 1];
    char batting_team[16];
    snprintf(team_a_name, sizeof(team_a_name), "%s", PQgetvalue(settings_result, 0, 0));
    snprintf(team_b_name, sizeof(team_b_name), "%s", PQgetvalue(settings_result, 0, 1));
    snprintf(batting_team, sizeof(batting_team), "%s", PQgetvalue(settings_result, 0, 2));
    PQclear(settings_result);
    char numeric[10][32];
    snprintf(numeric[0], sizeof(numeric[0]), "%lld", runs);
    snprintf(numeric[1], sizeof(numeric[1]), "%lld", wickets);
    snprintf(numeric[2], sizeof(numeric[2]), "%lld", legal_balls);
    snprintf(numeric[3], sizeof(numeric[3]), "%.12f", legal_balls > 0 ? (double)runs * 6.0 / (double)legal_balls : 0.0);
    snprintf(numeric[4], sizeof(numeric[4]), "%lld", fours);
    snprintf(numeric[5], sizeof(numeric[5]), "%lld", sixes);
    snprintf(numeric[6], sizeof(numeric[6]), "%d", batter_count);
    snprintf(numeric[7], sizeof(numeric[7]), "%d", bowler_count);
    snprintf(numeric[8], sizeof(numeric[8]), "%d", top_batter >= 0 ? batsmen[top_batter].runs : 0);
    snprintf(numeric[9], sizeof(numeric[9]), "%d", top_bowler >= 0 ? bowlers[top_bowler].wickets : 0);
    const char *parameters[] = {
        match_name, numeric[0], numeric[1], numeric[2], legal_balls > 0 ? numeric[3] : NULL,
        numeric[4], numeric[5], numeric[6], numeric[7], top_batter >= 0 ? batsmen[top_batter].name : "",
        numeric[8], top_bowler >= 0 ? bowlers[top_bowler].name : "", numeric[9],
        team_a_name, team_b_name, batting_team
    };
    PGresult *result = database_query(database,
        "INSERT INTO match_history (match_name,archived_at,runs,wickets,legal_balls,run_rate,fours,sixes,"
        "batter_count,bowler_count,top_scorer,top_runs,top_bowler,top_wickets,team_a_name,team_b_name,batting_team) "
        "VALUES ($1,CURRENT_TIMESTAMP,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id",
        16, parameters, PGRES_TUPLES_OK, "Could not archive the match", error, error_capacity);
    if (!result || PQntuples(result) != 1) {
        if (result) PQclear(result);
        if (!error[0]) snprintf(error, error_capacity, "Could not archive the match: no row was returned.");
        database_rollback(database); PQfinish(database); return 0;
    }
    *new_id = (int64_t)strtoll(PQgetvalue(result, 0, 0), NULL, 10);
    PQclear(result);
    if (!database_command(database, "COMMIT", "Could not commit the archived match", error, error_capacity)) {
        database_rollback(database); PQfinish(database); return 0;
    }
    PQfinish(database);
    return 1;
}

static void send_history(int socket_fd) {
    PGconn *database = open_database();
    if (!database) { send_error(socket_fd, 500, "Could not connect to PostgreSQL."); return; }
    char error[256] = {0};
    PGresult *result = database_query(database,
        "SELECT id,match_name,to_char(archived_at AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS'),"
        "runs,wickets,legal_balls,run_rate,fours,sixes,batter_count,bowler_count,top_scorer,top_runs,top_bowler,top_wickets,"
        "team_a_name,team_b_name,batting_team FROM match_history ORDER BY id DESC LIMIT 100",
        0, NULL, PGRES_TUPLES_OK, "Could not load match history", error, sizeof(error));
    if (!result) {
        PQfinish(database);
        send_error(socket_fd, 500, error[0] ? error : "Could not load match history.");
        return;
    }
    StringBuffer json;
    string_buffer_init(&json);
    string_buffer_append(&json, "{\"history\":[");
    for (int row = 0; row < PQntuples(result); row++) {
        if (row > 0) string_buffer_append(&json, ",");
        long long id = (long long)pg_column_int64(result, row, 0);
        long long runs = (long long)pg_column_int64(result, row, 3);
        long long wickets = (long long)pg_column_int64(result, row, 4);
        int legal_balls = pg_int(result, row, 5);
        string_buffer_appendf(&json, "{\"id\":%lld,\"name\":", id);
        string_buffer_json_string(&json, PQgetvalue(result, row, 1));
        string_buffer_append(&json, ",\"archived_at\":");
        string_buffer_json_string(&json, PQgetvalue(result, row, 2));
        string_buffer_appendf(&json,
            ",\"runs\":%lld,\"wickets\":%lld,\"legal_balls\":%d,\"overs\":\"%d.%d\",\"run_rate\":",
            runs, wickets, legal_balls, legal_balls / 6, legal_balls % 6);
        if (PQgetisnull(result, row, 6)) string_buffer_append(&json, "null");
        else string_buffer_appendf(&json, "%.2f", strtod(PQgetvalue(result, row, 6), NULL));
        string_buffer_appendf(&json,
            ",\"fours\":%d,\"sixes\":%d,\"batter_count\":%d,\"bowler_count\":%d,\"top_scorer\":",
            pg_int(result, row, 7), pg_int(result, row, 8), pg_int(result, row, 9), pg_int(result, row, 10));
        string_buffer_json_string(&json, PQgetvalue(result, row, 11));
        string_buffer_appendf(&json, ",\"top_runs\":%lld,\"top_bowler\":",
                              (long long)pg_column_int64(result, row, 12));
        string_buffer_json_string(&json, PQgetvalue(result, row, 13));
        string_buffer_appendf(&json, ",\"top_wickets\":%lld,\"team_a_name\":",
                              (long long)pg_column_int64(result, row, 14));
        string_buffer_json_string(&json, PQgetvalue(result, row, 15));
        string_buffer_append(&json, ",\"team_b_name\":");
        string_buffer_json_string(&json, PQgetvalue(result, row, 16));
        string_buffer_append(&json, ",\"batting_team\":");
        string_buffer_json_string(&json, PQgetvalue(result, row, 17));
        string_buffer_append(&json, "}");
    }
    string_buffer_append(&json, "]}");
    PQclear(result);
    PQfinish(database);
    send_json(socket_fd, 200, json.data);
    free(json.data);
}

static int batter_metric(const Batter *player, int metric) {
    if (metric == 0) return player->runs;
    if (metric == 1) return player->fours;
    return player->sixes;
}

static void append_batter_record(StringBuffer *json, const Batter *players, int count, int metric) {
    int highest = 0;
    for (int i = 0; i < count; i++) if (batter_metric(&players[i], metric) > highest) highest = batter_metric(&players[i], metric);
    string_buffer_appendf(json, "{\"value\":%d,\"names\":[", highest);
    int first = 1;
    if (highest > 0) {
        for (int i = 0; i < count; i++) {
            if (batter_metric(&players[i], metric) == highest) {
                if (!first) string_buffer_append(json, ",");
                string_buffer_json_string(json, players[i].name);
                first = 0;
            }
        }
    }
    string_buffer_append(json, "]}");
}

static void append_bowler_record(StringBuffer *json, const Bowler *players, int count) {
    int highest = 0;
    for (int i = 0; i < count; i++) if (players[i].wickets > highest) highest = players[i].wickets;
    string_buffer_appendf(json, "{\"value\":%d,\"names\":[", highest);
    int first = 1;
    if (highest > 0) {
        for (int i = 0; i < count; i++) {
            if (players[i].wickets == highest) {
                if (!first) string_buffer_append(json, ",");
                string_buffer_json_string(json, players[i].name);
                first = 0;
            }
        }
    }
    string_buffer_append(json, "]}");
}

static void send_state(int socket_fd) {
    Batter batsmen[MAX_ROSTER] = {0};
    Bowler bowlers[MAX_ROSTER] = {0};
    int batter_count = 0, bowler_count = 0;
    char error[256] = {0};
    MatchSettings match = { .team_a_name = "Team A", .team_b_name = "Team B", .batting_team = 0, .version = 1 };
    if (!load_players(batsmen, &batter_count, bowlers, &bowler_count, &match, error, sizeof(error))) {
        send_error(socket_fd, 500, error); return;
    }
    long long total_runs = 0, total_balls_faced = 0, total_legal_balls = 0, total_wickets = 0, total_fours = 0, total_sixes = 0;
    for (int i = 0; i < batter_count; i++) {
        total_runs += batsmen[i].runs; total_balls_faced += batsmen[i].balls;
        total_fours += batsmen[i].fours; total_sixes += batsmen[i].sixes;
    }
    for (int i = 0; i < bowler_count; i++) {
        total_legal_balls += bowlers[i].legal_balls; total_wickets += bowlers[i].wickets;
    }
    StringBuffer json;
    string_buffer_init(&json);
    string_buffer_append(&json, "{\"match\":{\"team_a_name\":");
    string_buffer_json_string(&json, match.team_a_name);
    string_buffer_append(&json, ",\"team_b_name\":");
    string_buffer_json_string(&json, match.team_b_name);
    string_buffer_append(&json, ",\"batting_team\":");
    string_buffer_json_string(&json, match.batting_team ? "team_b" : "team_a");
    string_buffer_appendf(&json, ",\"version\":%d},\"batsmen\":[", match.version);
    for (int i = 0; i < batter_count; i++) {
        Batter *player = &batsmen[i];
        if (i) string_buffer_append(&json, ",");
        string_buffer_appendf(&json, "{\"id\":%lld,\"name\":", (long long)player->id);
        string_buffer_json_string(&json, player->name);
        string_buffer_appendf(&json,
            ",\"ones\":%d,\"twos\":%d,\"threes\":%d,\"fours\":%d,\"sixes\":%d,\"balls\":%d,\"runs\":%d,\"strike_rate\":",
            player->ones, player->twos, player->threes, player->fours, player->sixes, player->balls, player->runs);
        if (player->balls > 0) string_buffer_appendf(&json, "%.2f", player->strike_rate);
        else string_buffer_append(&json, "null");
        string_buffer_append(&json, "}");
    }
    string_buffer_append(&json, "],\"bowlers\":[");
    for (int i = 0; i < bowler_count; i++) {
        Bowler *player = &bowlers[i];
        if (i) string_buffer_append(&json, ",");
        string_buffer_appendf(&json, "{\"id\":%lld,\"name\":", (long long)player->id);
        string_buffer_json_string(&json, player->name);
        string_buffer_appendf(&json, ",\"runs_conceded\":%d,\"legal_balls\":%d,\"wickets\":%d,\"overs\":", player->runs_conceded, player->legal_balls, player->wickets);
        string_buffer_json_string(&json, player->overs);
        string_buffer_append(&json, ",\"economy\":");
        if (player->legal_balls > 0) string_buffer_appendf(&json, "%.2f", player->economy);
        else string_buffer_append(&json, "null");
        string_buffer_append(&json, "}");
    }
    string_buffer_appendf(&json,
        "],\"summary\":{\"runs\":%lld,\"wickets\":%lld,\"balls\":%lld,\"legal_balls\":%lld,\"overs\":\"%lld.%lld\",\"run_rate\":",
        total_runs, total_wickets, total_balls_faced, total_legal_balls, total_legal_balls / 6, total_legal_balls % 6);
    if (total_legal_balls > 0) string_buffer_appendf(&json, "%.2f", (double)total_runs * 6.0 / (double)total_legal_balls);
    else string_buffer_append(&json, "null");
    string_buffer_appendf(&json, ",\"fours\":%lld,\"sixes\":%lld,\"batter_count\":%d,\"bowler_count\":%d},\"records\":{\"top_runs\":", total_fours, total_sixes, batter_count, bowler_count);
    append_batter_record(&json, batsmen, batter_count, 0);
    string_buffer_append(&json, ",\"most_fours\":"); append_batter_record(&json, batsmen, batter_count, 1);
    string_buffer_append(&json, ",\"most_sixes\":"); append_batter_record(&json, batsmen, batter_count, 2);
    string_buffer_append(&json, ",\"most_wickets\":"); append_bowler_record(&json, bowlers, bowler_count);
    string_buffer_append(&json, "}}");
    send_json(socket_fd, 200, json.data);
    free(json.data);
}

static int contains_case_insensitive(const char *text, const char *needle) {
    size_t needle_length = strlen(needle);
    if (needle_length == 0) return 1;
    for (const char *cursor = text; *cursor; cursor++) {
        if (strncasecmp(cursor, needle, needle_length) == 0) return 1;
    }
    return 0;
}

static size_t curl_response_writer(char *data, size_t size, size_t count, void *user_data) {
    size_t bytes = size * count;
    StringBuffer *response = user_data;
    if (response->length + bytes > 32768) return 0;
    string_buffer_append_n(response, data, bytes);
    return bytes;
}

static int json_find_named_string(const char *json, const char *wanted, char *output, size_t capacity) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", wanted);
    const size_t pattern_length = strlen(pattern);
    const char *cursor = json;
    while ((cursor = strstr(cursor, pattern)) != NULL) {
        const char *value = skip_whitespace(cursor + pattern_length);
        if (*value == ':') {
            value = skip_whitespace(value + 1);
            if (*value == '"' && parse_json_string(&value, output, capacity)) return 1;
        }
        cursor += pattern_length;
    }
    return 0;
}

static void build_match_context(StringBuffer *context, const Batter *batsmen, int batter_count,
                                const Bowler *bowlers, int bowler_count) {
    long long runs = 0, balls_faced = 0, legal_balls = 0, wickets = 0;
    for (int i = 0; i < batter_count; i++) { runs += batsmen[i].runs; balls_faced += batsmen[i].balls; }
    for (int i = 0; i < bowler_count; i++) { legal_balls += bowlers[i].legal_balls; wickets += bowlers[i].wickets; }
    string_buffer_appendf(context, "{\"score\":{\"runs\":%lld,\"wickets\":%lld,\"overs\":\"%lld.%lld\",\"balls_faced\":%lld,\"run_rate\":",
        runs, wickets, legal_balls / 6, legal_balls % 6, balls_faced);
    if (legal_balls) string_buffer_appendf(context, "%.2f", (double)runs * 6.0 / legal_balls);
    else string_buffer_append(context, "null");
    string_buffer_append(context, "},\"batsmen\":[");
    for (int i = 0; i < batter_count; i++) {
        const Batter *p = &batsmen[i];
        if (i) string_buffer_append(context, ",");
        string_buffer_append(context, "{\"name\":"); string_buffer_json_string(context, p->name);
        string_buffer_appendf(context, ",\"runs\":%d,\"balls\":%d,\"fours\":%d,\"sixes\":%d,\"strike_rate\":", p->runs, p->balls, p->fours, p->sixes);
        if (p->balls) string_buffer_appendf(context, "%.2f", p->strike_rate);
        else string_buffer_append(context, "null");
        string_buffer_append(context, "}");
    }
    string_buffer_append(context, "],\"bowlers\":[");
    for (int i = 0; i < bowler_count; i++) {
        const Bowler *p = &bowlers[i];
        if (i) string_buffer_append(context, ",");
        string_buffer_append(context, "{\"name\":"); string_buffer_json_string(context, p->name);
        string_buffer_appendf(context, ",\"runs_conceded\":%d,\"overs\":\"%s\",\"wickets\":%d,\"economy\":", p->runs_conceded, p->overs, p->wickets);
        if (p->legal_balls) string_buffer_appendf(context, "%.2f", p->economy);
        else string_buffer_append(context, "null");
        string_buffer_append(context, "}");
    }
    string_buffer_append(context, "]}");
}

static int external_ai_answer(const char *question, const char *match_context, char *answer, size_t answer_capacity) {
    const char *api_key = getenv("AI_API_KEY");
    if (!api_key || !*api_key) return 0;
    const char *api_url = getenv("AI_API_URL");
    const char *model = getenv("AI_MODEL");
    if (!api_url || !*api_url) api_url = "https://api.openai.com/v1/chat/completions";
    if (!model || !*model) model = "gpt-4o-mini";

    StringBuffer user_message, request_body, response_body, authorization;
    string_buffer_init(&user_message); string_buffer_init(&request_body);
    string_buffer_init(&response_body); string_buffer_init(&authorization);
    string_buffer_append(&user_message, "Question from the scorekeeper: ");
    string_buffer_append(&user_message, question);
    string_buffer_append(&user_message, "\n\nCurrent scorecard data (source of truth): ");
    string_buffer_append(&user_message, match_context);
    string_buffer_append(&request_body, "{\"model\":"); string_buffer_json_string(&request_body, model);
    string_buffer_append(&request_body, ",\"temperature\":0.2,\"messages\":[{\"role\":\"system\",\"content\":");
    string_buffer_json_string(&request_body,
        "You are ScoreLab's cricket match assistant. Answer concisely using only the supplied scorecard facts. "
        "Do not invent players, events, venues, or results. If a statistic is missing, say it is not recorded. "
        "Offer neutral explanations and scoring help; do not give betting advice.");
    string_buffer_append(&request_body, "},{\"role\":\"user\",\"content\":");
    string_buffer_json_string(&request_body, user_message.data);
    string_buffer_append(&request_body, "}]}");

    string_buffer_append(&authorization, "Authorization: Bearer ");
    string_buffer_append(&authorization, api_key);
    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, authorization.data);
    CURL *curl = curl_easy_init();
    int success = 0;
    if (curl && headers) {
        curl_easy_setopt(curl, CURLOPT_URL, api_url);
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, request_body.data);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)request_body.length);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_response_writer);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 8L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 20L);
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
        CURLcode result = curl_easy_perform(curl);
        long http_status = 0;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_status);
        if (result == CURLE_OK && http_status >= 200 && http_status < 300) {
            success = json_find_named_string(response_body.data, "content", answer, answer_capacity);
        }
    }
    if (curl) curl_easy_cleanup(curl);
    if (headers) curl_slist_free_all(headers);
    free(user_message.data); free(request_body.data); free(response_body.data); free(authorization.data);
    return success;
}

static void build_local_answer(const char *question, const Batter *batsmen, int batter_count,
                               const Bowler *bowlers, int bowler_count, StringBuffer *answer) {
    long long total_runs = 0, legal_balls = 0, wickets = 0, total_fours = 0, total_sixes = 0;
    int top_batter = -1, top_bowler = -1, best_economy_bowler = -1;
    int most_fours = -1, most_sixes = -1;
    for (int i = 0; i < batter_count; i++) {
        total_runs += batsmen[i].runs;
        total_fours += batsmen[i].fours; total_sixes += batsmen[i].sixes;
        if (top_batter < 0 || batsmen[i].runs > batsmen[top_batter].runs) top_batter = i;
        if (most_fours < 0 || batsmen[i].fours > batsmen[most_fours].fours) most_fours = i;
        if (most_sixes < 0 || batsmen[i].sixes > batsmen[most_sixes].sixes) most_sixes = i;
    }
    for (int i = 0; i < bowler_count; i++) {
        legal_balls += bowlers[i].legal_balls; wickets += bowlers[i].wickets;
        if (top_bowler < 0 || bowlers[i].wickets > bowlers[top_bowler].wickets) top_bowler = i;
        if (bowlers[i].legal_balls > 0 && (best_economy_bowler < 0 || bowlers[i].economy < bowlers[best_economy_bowler].economy)) best_economy_bowler = i;
    }
    if (!batter_count && !bowler_count) {
        string_buffer_append(answer, "I’m ready to help with this innings. Add a batter or bowler first, and I can explain the score, run rate, strike rates, economy, and leading performances.");
        return;
    }
    if (contains_case_insensitive(question, "help") || contains_case_insensitive(question, "what can")) {
        string_buffer_append(answer, "Ask me who is leading, what the run rate is, who has the most wickets, which bowler has the best economy, or for a concise innings summary. I read the current scorecard, so my answers update when you save changes.");
        return;
    }
    if (contains_case_insensitive(question, "run rate") || contains_case_insensitive(question, "runrate") || contains_case_insensitive(question, "overs")) {
        if (legal_balls > 0) string_buffer_appendf(answer, "The score is %lld from %lld.%lld overs, for a run rate of %.2f runs per over. This uses the legal balls entered in the bowling card.", total_runs, legal_balls / 6, legal_balls % 6, (double)total_runs * 6.0 / legal_balls);
        else string_buffer_append(answer, "No bowling overs have been recorded yet, so the innings run rate is not available. Add a bowler’s legal balls to calculate it.");
        return;
    }
    if (contains_case_insensitive(question, "economy")) {
        if (best_economy_bowler >= 0) string_buffer_appendf(answer, "%s has the best recorded economy at %.2f runs per over (%d conceded from %s overs).", bowlers[best_economy_bowler].name, bowlers[best_economy_bowler].economy, bowlers[best_economy_bowler].runs_conceded, bowlers[best_economy_bowler].overs);
        else string_buffer_append(answer, "No legal bowling balls have been recorded yet, so economy rates are not available.");
        return;
    }
    if (contains_case_insensitive(question, "wicket") || contains_case_insensitive(question, "bowler")) {
        if (top_bowler >= 0 && bowlers[top_bowler].wickets > 0) string_buffer_appendf(answer, "%s leads the bowling card with %d wicket%s from %s overs, conceding %d runs.", bowlers[top_bowler].name, bowlers[top_bowler].wickets, bowlers[top_bowler].wickets == 1 ? "" : "s", bowlers[top_bowler].overs, bowlers[top_bowler].runs_conceded);
        else string_buffer_append(answer, "No bowler has a wicket recorded yet. Bowling figures can still be compared by economy once legal balls are entered.");
        return;
    }
    if (contains_case_insensitive(question, "four") || contains_case_insensitive(question, "boundary")) {
        if (most_fours >= 0) string_buffer_appendf(answer, "%s has the most fours with %d. The innings has %lld fours in total.", batsmen[most_fours].name, batsmen[most_fours].fours, total_fours);
        return;
    }
    if (contains_case_insensitive(question, "six")) {
        if (most_sixes >= 0) string_buffer_appendf(answer, "%s has the most sixes with %d. The innings has %lld sixes in total.", batsmen[most_sixes].name, batsmen[most_sixes].sixes, total_sixes);
        return;
    }
    if (top_batter >= 0 && (contains_case_insensitive(question, "top") || contains_case_insensitive(question, "leading") || contains_case_insensitive(question, "batter") || contains_case_insensitive(question, "score"))) {
        string_buffer_appendf(answer, "%s is the top scorer with %d runs from %d balls (strike rate %.2f). The team total is %lld/%lld.", batsmen[top_batter].name, batsmen[top_batter].runs, batsmen[top_batter].balls, batsmen[top_batter].balls ? batsmen[top_batter].strike_rate : 0.0, total_runs, wickets);
        return;
    }
    string_buffer_appendf(answer, "Current innings: %lld/%lld from %lld.%lld overs", total_runs, wickets, legal_balls / 6, legal_balls % 6);
    if (legal_balls > 0) string_buffer_appendf(answer, " (run rate %.2f)", (double)total_runs * 6.0 / legal_balls);
    if (top_batter >= 0) string_buffer_appendf(answer, ". Top scorer: %s, %d runs", batsmen[top_batter].name, batsmen[top_batter].runs);
    if (top_bowler >= 0 && bowlers[top_bowler].wickets > 0) string_buffer_appendf(answer, ". Leading bowler: %s, %d wickets", bowlers[top_bowler].name, bowlers[top_bowler].wickets);
    string_buffer_append(answer, ". Ask about run rate, batting impact, wickets, or bowling economy for a focused breakdown.");
}

static void send_agents(int socket_fd) {
    const int external_configured = getenv("AI_API_KEY") && *getenv("AI_API_KEY");
    StringBuffer response;
    string_buffer_init(&response);
    string_buffer_appendf(&response, "{\"agents\":[{\"id\":\"match-analyst\",\"name\":\"Match Analyst\",\"status\":\"ready\",\"mode\":\"%s\"},{\"id\":\"data-guard\",\"name\":\"Scorecard Data Guard\",\"status\":\"ready\",\"mode\":\"local-validation\"}],\"external_ai_configured\":%s}", external_configured ? "api-with-local-fallback" : "local", external_configured ? "true" : "false");
    send_json(socket_fd, 200, response.data);
    free(response.data);
}

static void send_assistant_answer(int socket_fd, const char *body) {
    char question[1201] = {0};
    if (!json_get_string(body, "question", question, sizeof(question)) || question[0] == '\0') {
        send_error(socket_fd, 400, "Send a question in the 'question' field."); return;
    }
    Batter batsmen[MAX_ROSTER] = {0}; Bowler bowlers[MAX_ROSTER] = {0};
    int batter_count = 0, bowler_count = 0; char error[256] = {0};
    if (!load_players(batsmen, &batter_count, bowlers, &bowler_count, NULL, error, sizeof(error))) { send_error(socket_fd, 500, error); return; }
    StringBuffer context, answer, response;
    string_buffer_init(&context); string_buffer_init(&answer); string_buffer_init(&response);
    build_match_context(&context, batsmen, batter_count, bowlers, bowler_count);
    char external_answer[8192] = {0};
    int used_external = external_ai_answer(question, context.data, external_answer, sizeof(external_answer));
    if (used_external) string_buffer_append(&answer, external_answer);
    else build_local_answer(question, batsmen, batter_count, bowlers, bowler_count, &answer);
    string_buffer_append(&response, "{\"agent\":\"Match Analyst\",\"mode\":");
    const char *api_key = getenv("AI_API_KEY");
    string_buffer_json_string(&response, used_external ? "external-api" : (api_key && *api_key ? "local-fallback" : "local"));
    string_buffer_append(&response, ",\"answer\":"); string_buffer_json_string(&response, answer.data);
    string_buffer_append(&response, "}");
    send_json(socket_fd, 200, response.data);
    free(context.data); free(answer.data); free(response.data);
}

static int parse_record_id(const char *path, const char *collection, int64_t *id) {
    char prefix[64];
    snprintf(prefix, sizeof(prefix), "/api/%s/", collection);
    size_t prefix_length = strlen(prefix);
    if (strncmp(path, prefix, prefix_length) != 0 || !isdigit((unsigned char)path[prefix_length])) return 0;
    errno = 0;
    char *end = NULL;
    long long value = strtoll(path + prefix_length, &end, 10);
    if (errno || value <= 0 || !end || *end != '\0') return 0;
    *id = (int64_t)value;
    return 1;
}

static void handle_post(int socket_fd, const char *path, const char *body) {
    char error[256] = {0};
    if (strcmp(path, "/api/assistant") == 0) {
        send_assistant_answer(socket_fd, body); return;
    }
    if (strcmp(path, "/api/batsmen") == 0) {
        BatterInput input = {0}; int64_t id = 0;
        if (!parse_batter_input(body, &input, error, sizeof(error))) { send_error(socket_fd, 400, error); return; }
        if (!database_insert_batter(&input, &id, error, sizeof(error))) { send_error(socket_fd, strstr(error, "at most") ? 400 : 500, error); return; }
        char response[96]; snprintf(response, sizeof(response), "{\"id\":%lld}", (long long)id); send_json(socket_fd, 201, response); return;
    }
    if (strcmp(path, "/api/bowlers") == 0) {
        BowlerInput input = {0}; int64_t id = 0;
        if (!parse_bowler_input(body, &input, error, sizeof(error))) { send_error(socket_fd, 400, error); return; }
        if (!database_insert_bowler(&input, &id, error, sizeof(error))) { send_error(socket_fd, strstr(error, "at most") ? 400 : 500, error); return; }
        char response[96]; snprintf(response, sizeof(response), "{\"id\":%lld}", (long long)id); send_json(socket_fd, 201, response); return;
    }
    if (strcmp(path, "/api/history") == 0) {
        char match_name[MAX_NAME_BYTES + 1] = {0};
        if (!json_get_string(body, "name", match_name, sizeof(match_name))) snprintf(match_name, sizeof(match_name), "Match snapshot");
        trim_name(match_name);
        if (!match_name[0]) snprintf(match_name, sizeof(match_name), "Match snapshot");
        if (!valid_name(match_name, error, sizeof(error))) { send_error(socket_fd, 400, error); return; }
        int64_t id = 0;
        if (!database_archive_match(match_name, &id, error, sizeof(error))) {
            send_error(socket_fd, strstr(error, "at least one") ? 400 : 500, error);
            return;
        }
        char response[128]; snprintf(response, sizeof(response), "{\"id\":%lld,\"status\":\"archived\"}", (long long)id);
        send_json(socket_fd, 201, response); return;
    }
    if (strcmp(path, "/api/reset") == 0) {
        if (!database_reset(error, sizeof(error))) { send_error(socket_fd, 500, error); return; }
        send_json(socket_fd, 200, "{\"status\":\"cleared\"}"); return;
    }
    send_error(socket_fd, 404, "Not found.");
}

static void handle_put(int socket_fd, const char *path, const char *body) {
    int64_t id;
    char error[256] = {0};
    if (strcmp(path, "/api/match/settings") == 0) {
        MatchSettingsInput input = {0};
        int new_version = 0;
        if (!parse_match_settings_input(body, &input, error, sizeof(error))) {
            send_error(socket_fd, 400, error); return;
        }
        int result = database_update_match_settings(&input, &new_version, error, sizeof(error));
        if (result < 0) { send_error(socket_fd, 500, error); return; }
        if (result == 0) { send_error(socket_fd, 409, "Match details changed elsewhere. Refresh and try again."); return; }
        char response[96];
        snprintf(response, sizeof(response), "{\"status\":\"updated\",\"version\":%d}", new_version);
        send_json(socket_fd, 200, response); return;
    }
    if (parse_record_id(path, "batsmen", &id)) {
        BatterInput input = {0};
        if (!parse_batter_input(body, &input, error, sizeof(error))) { send_error(socket_fd, 400, error); return; }
        int result = database_update_batter(id, &input, error, sizeof(error));
        if (result < 0) { send_error(socket_fd, 500, error); return; }
        if (result == 0) { send_error(socket_fd, 404, "That player is no longer on the scorecard."); return; }
        char response[96]; snprintf(response, sizeof(response), "{\"status\":\"updated\",\"id\":%lld}", (long long)id); send_json(socket_fd, 200, response); return;
    }
    if (parse_record_id(path, "bowlers", &id)) {
        BowlerInput input = {0};
        if (!parse_bowler_input(body, &input, error, sizeof(error))) { send_error(socket_fd, 400, error); return; }
        int result = database_update_bowler(id, &input, error, sizeof(error));
        if (result < 0) { send_error(socket_fd, 500, error); return; }
        if (result == 0) { send_error(socket_fd, 404, "That player is no longer on the scorecard."); return; }
        char response[96]; snprintf(response, sizeof(response), "{\"status\":\"updated\",\"id\":%lld}", (long long)id); send_json(socket_fd, 200, response); return;
    }
    send_error(socket_fd, 404, "Not found.");
}

static void handle_delete(int socket_fd, const char *path) {
    int64_t id;
    char error[256] = {0};
    const char *table = NULL;
    if (parse_record_id(path, "batsmen", &id)) table = "batsmen";
    else if (parse_record_id(path, "bowlers", &id)) table = "bowlers";
    else { send_error(socket_fd, 404, "Not found."); return; }
    int result = database_delete(table, id, error, sizeof(error));
    if (result < 0) { send_error(socket_fd, 500, error); return; }
    if (result == 0) { send_error(socket_fd, 404, "That player is no longer on the scorecard."); return; }
    send_json(socket_fd, 200, "{\"status\":\"deleted\"}");
}

static void serve_image_asset(int socket_fd, const char *filename) {
    char path[1200];
    snprintf(path, sizeof(path), "%s/assets/%s", document_root, filename);
    FILE *file = fopen(path, "rb");
    if (!file) { send_error(socket_fd, 404, "Image asset not found."); return; }
    if (fseek(file, 0, SEEK_END) != 0) { fclose(file); send_error(socket_fd, 500, "Could not read image asset."); return; }
    long file_length = ftell(file);
    if (file_length < 0 || file_length > 2 * 1024 * 1024 || fseek(file, 0, SEEK_SET) != 0) {
        fclose(file); send_error(socket_fd, 500, "Image asset is too large or unreadable."); return;
    }
    unsigned char *content = malloc((size_t)file_length ? (size_t)file_length : 1);
    if (!content) { fclose(file); send_error(socket_fd, 500, "Not enough memory to serve image asset."); return; }
    size_t bytes_read = fread(content, 1, (size_t)file_length, file);
    fclose(file);
    if (bytes_read != (size_t)file_length) { free(content); send_error(socket_fd, 500, "Could not read image asset."); return; }
    const char *extension = strrchr(filename, '.');
    const char *content_type = extension && strcmp(extension, ".webp") == 0 ? "image/webp" : "image/jpeg";
    send_response(socket_fd, 200, content_type, content, bytes_read);
    free(content);
}

static int parse_video_range(const char *headers, size_t headers_length, size_t file_length,
                             size_t *range_start, size_t *range_end) {
    if (file_length == 0) return -1;
    const char *limit = headers + headers_length;
    const char *line = memchr(headers, '\n', headers_length);
    if (!line) return 0;
    line++;
    while (line < limit) {
        const char *newline = memchr(line, '\n', (size_t)(limit - line));
        size_t line_length = newline ? (size_t)(newline - line) : (size_t)(limit - line);
        if (line_length && line[line_length - 1] == '\r') line_length--;
        if (line_length == 0) break;
        if (line_length >= 6 && strncasecmp(line, "Range:", 6) == 0) {
            char value[128];
            size_t value_length = line_length - 6;
            const char *value_start = line + 6;
            while (value_length && isspace((unsigned char)*value_start)) { value_start++; value_length--; }
            while (value_length && isspace((unsigned char)value_start[value_length - 1])) value_length--;
            if (value_length == 0 || value_length >= sizeof(value)) return -1;
            memcpy(value, value_start, value_length);
            value[value_length] = '\0';
            if (strncasecmp(value, "bytes=", 6) != 0 || strchr(value, ',')) return -1;
            char *cursor = value + 6;
            while (isspace((unsigned char)*cursor)) cursor++;
            errno = 0;
            char *number_end = NULL;
            if (*cursor == '-') {
                cursor++;
                unsigned long long suffix = strtoull(cursor, &number_end, 10);
                if (number_end == cursor || errno == ERANGE || suffix == 0) return -1;
                while (isspace((unsigned char)*number_end)) number_end++;
                if (*number_end != '\0') return -1;
                *range_start = suffix >= file_length ? 0 : file_length - (size_t)suffix;
                *range_end = file_length - 1;
                return 1;
            }
            unsigned long long first = strtoull(cursor, &number_end, 10);
            if (number_end == cursor || errno == ERANGE || first >= file_length || *number_end != '-') return -1;
            cursor = number_end + 1;
            while (isspace((unsigned char)*cursor)) cursor++;
            if (*cursor == '\0') {
                *range_start = (size_t)first;
                *range_end = file_length - 1;
                return 1;
            }
            errno = 0;
            unsigned long long last = strtoull(cursor, &number_end, 10);
            if (number_end == cursor || errno == ERANGE) return -1;
            while (isspace((unsigned char)*number_end)) number_end++;
            if (*number_end != '\0' || last < first) return -1;
            *range_start = (size_t)first;
            *range_end = last >= file_length ? file_length - 1 : (size_t)last;
            return 1;
        }
        if (!newline) break;
        line = newline + 1;
    }
    return 0;
}

static void serve_video_asset(int socket_fd, const char *filename, const char *request_headers, size_t header_length) {
    char path[1200];
    snprintf(path, sizeof(path), "%s/assets/%s", document_root, filename);
    FILE *file = fopen(path, "rb");
    if (!file) { send_error(socket_fd, 404, "Video asset not found."); return; }
    if (fseek(file, 0, SEEK_END) != 0) { fclose(file); send_error(socket_fd, 500, "Could not inspect video asset."); return; }
    long length = ftell(file);
    if (length < 0 || length > 10 * 1024 * 1024 || fseek(file, 0, SEEK_SET) != 0) {
        fclose(file); send_error(socket_fd, 500, "Video asset is too large or unreadable."); return;
    }
    size_t file_length = (size_t)length, start = 0, end = file_length ? file_length - 1 : 0;
    int range_result = parse_video_range(request_headers, header_length, file_length, &start, &end);
    if (range_result < 0) {
        char header[256];
        int header_size = snprintf(header, sizeof(header),
            "HTTP/1.1 416 %s\r\nAccept-Ranges: bytes\r\nContent-Range: bytes */%zu\r\n"
            "Content-Length: 0\r\nConnection: close\r\n\r\n", status_text(416), file_length);
        if (header_size > 0) send_all(socket_fd, header, (size_t)header_size);
        fclose(file);
        return;
    }
    size_t response_length = file_length ? end - start + 1 : 0;
    char header[512];
    int header_size;
    if (range_result > 0) {
        header_size = snprintf(header, sizeof(header),
            "HTTP/1.1 206 %s\r\nContent-Type: video/mp4\r\nContent-Length: %zu\r\n"
            "Accept-Ranges: bytes\r\nContent-Range: bytes %zu-%zu/%zu\r\n"
            "Cache-Control: public, max-age=3600\r\nX-Content-Type-Options: nosniff\r\n"
            "Connection: close\r\n\r\n", status_text(206), response_length, start, end, file_length);
    } else {
        header_size = snprintf(header, sizeof(header),
            "HTTP/1.1 200 %s\r\nContent-Type: video/mp4\r\nContent-Length: %zu\r\n"
            "Accept-Ranges: bytes\r\nCache-Control: public, max-age=3600\r\n"
            "X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
            status_text(200), response_length);
    }
    if (header_size < 0 || (size_t)header_size >= sizeof(header) || send_all(socket_fd, header, (size_t)header_size) != 0) {
        fclose(file);
        return;
    }
    if (response_length == 0) { fclose(file); return; }
    if (fseek(file, (long)start, SEEK_SET) != 0) { fclose(file); return; }
    unsigned char chunk[16384];
    size_t remaining = response_length;
    while (remaining > 0) {
        size_t wanted = remaining < sizeof(chunk) ? remaining : sizeof(chunk);
        size_t bytes_read = fread(chunk, 1, wanted, file);
        if (bytes_read == 0 || send_all(socket_fd, chunk, bytes_read) != 0) break;
        remaining -= bytes_read;
    }
    fclose(file);
}

static void serve_index(int socket_fd) {
    char path[1200];
    snprintf(path, sizeof(path), "%s/index.html", document_root);
    FILE *file = fopen(path, "rb");
    if (!file) { send_error(socket_fd, 500, "Could not find index.html beside the C server."); return; }
    if (fseek(file, 0, SEEK_END) != 0) { fclose(file); send_error(socket_fd, 500, "Could not read the website file."); return; }
    long file_length = ftell(file);
    if (file_length < 0 || file_length > 5 * 1024 * 1024 || fseek(file, 0, SEEK_SET) != 0) {
        fclose(file); send_error(socket_fd, 500, "Website file is too large or could not be read."); return;
    }
    char *content = malloc((size_t)file_length + 1);
    if (!content) { fclose(file); send_error(socket_fd, 500, "Not enough memory to serve the website."); return; }
    size_t bytes_read = fread(content, 1, (size_t)file_length, file);
    fclose(file);
    if (bytes_read != (size_t)file_length) { free(content); send_error(socket_fd, 500, "Could not read the website file."); return; }
    send_response(socket_fd, 200, "text/html; charset=utf-8", content, bytes_read);
    free(content);
}

static int parse_content_length(const char *headers, size_t *length) {
    *length = 0;
    const char *line = strstr(headers, "\r\n");
    if (!line) return 1;
    line += 2;
    while (*line && !(line[0] == '\r' && line[1] == '\n')) {
        const char *end = strstr(line, "\r\n");
        if (!end) return 0;
        if ((size_t)(end - line) >= 15 && strncasecmp(line, "Content-Length:", 15) == 0) {
            const char *value = line + 15;
            while (value < end && isspace((unsigned char)*value)) value++;
            if (value == end || !isdigit((unsigned char)*value)) return 0;
            size_t parsed = 0;
            while (value < end && isdigit((unsigned char)*value)) {
                parsed = parsed * 10 + (size_t)(*value++ - '0');
                if (parsed > MAX_REQUEST_BODY) return -1;
            }
            while (value < end && isspace((unsigned char)*value)) value++;
            if (value != end) return 0;
            *length = parsed;
        }
        line = end + 2;
    }
    return 1;
}

static int read_request(int socket_fd, char *buffer, size_t capacity, size_t *header_length, size_t *body_length) {
    size_t used = 0;
    char *separator = NULL;
    while (!separator) {
        if (used + 1 >= capacity) return -1;
        ssize_t got = recv(socket_fd, buffer + used, capacity - used - 1, 0);
        if (got < 0) { if (errno == EINTR) continue; return 0; }
        if (got == 0) return 0;
        used += (size_t)got; buffer[used] = '\0';
        separator = strstr(buffer, "\r\n\r\n");
    }
    *header_length = (size_t)(separator - buffer) + 4;
    int content_result = parse_content_length(buffer, body_length);
    if (content_result < 0) return -2;
    if (content_result == 0) return -1;
    if (*body_length > MAX_REQUEST_BODY || *header_length + *body_length + 1 > capacity) return -2;
    while (used < *header_length + *body_length) {
        ssize_t got = recv(socket_fd, buffer + used, capacity - used - 1, 0);
        if (got < 0) { if (errno == EINTR) continue; return 0; }
        if (got == 0) return 0;
        used += (size_t)got; buffer[used] = '\0';
    }
    buffer[*header_length + *body_length] = '\0';
    return 1;
}

static void handle_client(int socket_fd) {
    char *buffer = malloc(REQUEST_BUFFER_SIZE);
    if (!buffer) { send_error(socket_fd, 500, "Not enough memory to process request."); return; }
    size_t header_length = 0, body_length = 0;
    int read_result = read_request(socket_fd, buffer, REQUEST_BUFFER_SIZE, &header_length, &body_length);
    if (read_result == -2) { send_error(socket_fd, 413, "Request body is too large."); free(buffer); return; }
    if (read_result <= 0) { send_error(socket_fd, 400, "Could not read the HTTP request."); free(buffer); return; }
    char method[16] = {0}, target[2048] = {0};
    if (sscanf(buffer, "%15s %2047s", method, target) != 2) {
        send_error(socket_fd, 400, "Invalid HTTP request line."); free(buffer); return;
    }
    char *query = strchr(target, '?');
    if (query) *query = '\0';
    char *body = buffer + header_length;
    fprintf(stdout, "%s %s\n", method, target);
    fflush(stdout);
    if (strcmp(method, "GET") == 0) {
        if (strcmp(target, "/") == 0 || strcmp(target, "/index.html") == 0 ||
            strcmp(target, "/overview") == 0 || strcmp(target, "/performance") == 0 || strcmp(target, "/scorecard") == 0 ||
            strcmp(target, "/history") == 0 || strcmp(target, "/analyst") == 0 ||
            strcmp(target, "/signin") == 0 || strcmp(target, "/overview/") == 0 ||
            strcmp(target, "/performance/") == 0 ||
            strcmp(target, "/scorecard/") == 0 || strcmp(target, "/history/") == 0 ||
            strcmp(target, "/analyst/") == 0 || strcmp(target, "/signin/") == 0) serve_index(socket_fd);
        else if (strcmp(target, "/assets/scorelab-cricket-cinematic.jpg") == 0) serve_image_asset(socket_fd, "scorelab-cricket-cinematic.jpg");
        else if (strcmp(target, "/assets/scorelab-immersive-arena.jpg") == 0) serve_image_asset(socket_fd, "scorelab-immersive-arena.jpg");
        else if (strcmp(target, "/assets/entry-hands.jpg") == 0) serve_image_asset(socket_fd, "entry-hands.jpg");
        else if (strcmp(target, "/assets/stadium-sunset.jpg") == 0) serve_image_asset(socket_fd, "stadium-sunset.jpg");
        else if (strcmp(target, "/assets/fireworks-arena.jpg") == 0) serve_image_asset(socket_fd, "fireworks-arena.jpg");
        else if (strcmp(target, "/assets/fireworks-crowd.jpg") == 0) serve_image_asset(socket_fd, "fireworks-crowd.jpg");
        else if (strcmp(target, "/assets/player-entrance.jpg") == 0) serve_image_asset(socket_fd, "player-entrance.jpg");
        else if (strcmp(target, "/assets/match-arena-sunset.webp") == 0) serve_image_asset(socket_fd, "match-arena-sunset.webp");
        else if (strcmp(target, "/assets/match-arena-aerial.webp") == 0) serve_image_asset(socket_fd, "match-arena-aerial.webp");
        else if (strcmp(target, "/assets/match-arena-futuristic.webp") == 0) serve_image_asset(socket_fd, "match-arena-futuristic.webp");
        else if (strcmp(target, "/assets/match-arena-fireworks-wide.webp") == 0) serve_image_asset(socket_fd, "match-arena-fireworks-wide.webp");
        else if (strcmp(target, "/assets/match-arena-fireworks-field.webp") == 0) serve_image_asset(socket_fd, "match-arena-fireworks-field.webp");
        else if (strcmp(target, "/assets/signin-cricket-poster.jpg") == 0) serve_image_asset(socket_fd, "signin-cricket-poster.jpg");
        else if (strcmp(target, "/assets/signin-cricket-loop.mp4") == 0) serve_video_asset(socket_fd, "signin-cricket-loop.mp4", buffer, header_length);
        else if (strcmp(target, "/assets/signin-drone-poster.jpg") == 0) serve_image_asset(socket_fd, "signin-drone-poster.jpg");
        else if (strcmp(target, "/assets/signin-drone-loop.mp4") == 0) serve_video_asset(socket_fd, "signin-drone-loop.mp4", buffer, header_length);
        else if (strcmp(target, "/api/health") == 0) send_json(socket_fd, 200, "{\"status\":\"ok\",\"storage\":\"postgresql\",\"backend\":\"c\"}");
        else if (strcmp(target, "/api/agents") == 0) send_agents(socket_fd);
        else if (strcmp(target, "/api/state") == 0) send_state(socket_fd);
        else if (strcmp(target, "/api/history") == 0) send_history(socket_fd);
        else send_error(socket_fd, 404, "Not found.");
    } else if (strcmp(method, "POST") == 0) {
        handle_post(socket_fd, target, body);
    } else if (strcmp(method, "PUT") == 0) {
        handle_put(socket_fd, target, body);
    } else if (strcmp(method, "DELETE") == 0) {
        handle_delete(socket_fd, target);
    } else {
        send_error(socket_fd, 405, "Method not allowed.");
    }
    (void)body_length;
    free(buffer);
}

static void *client_thread(void *argument) {
    ClientArgs *client = argument;
    int socket_fd = client->socket_fd;
    free(client);
    handle_client(socket_fd);
    close(socket_fd);
    return NULL;
}

static void stop_server(int signal_number) {
    (void)signal_number;
    keep_running = 0;
    int fd = listen_fd;
    listen_fd = -1;
    if (fd >= 0) close(fd);
}

int main(void) {
    if (!database_connection_string()) {
        fprintf(stderr, "DATABASE_URL must be configured for PostgreSQL.\n");
        return EXIT_FAILURE;
    }
    const char *root_environment = getenv("SCORECARD_ROOT");
    if (root_environment && *root_environment) snprintf(document_root, sizeof(document_root), "%s", root_environment);
    const char *port_environment = getenv("PORT");
    int port = port_environment && *port_environment ? atoi(port_environment) : DEFAULT_PORT;
    if (port < 1 || port > 65535) {
        fprintf(stderr, "PORT must be a number from 1 to 65535.\n");
        return EXIT_FAILURE;
    }
    if (!initialize_database()) return EXIT_FAILURE;
    if (curl_global_init(CURL_GLOBAL_DEFAULT) != CURLE_OK) {
        fprintf(stderr, "Could not initialize the optional AI HTTP client.\\n");
        return EXIT_FAILURE;
    }
    signal(SIGINT, stop_server);
    signal(SIGTERM, stop_server);

    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) { perror("socket"); return EXIT_FAILURE; }
    int enabled = 1;
    setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &enabled, sizeof(enabled));
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons((uint16_t)port);
    if (bind(listen_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind"); close(listen_fd); return EXIT_FAILURE;
    }
    if (listen(listen_fd, 64) < 0) { perror("listen"); close(listen_fd); return EXIT_FAILURE; }
    printf("Professionals C backend listening on 0.0.0.0:%d\nPostgreSQL: connected\n", port);
    fflush(stdout);

    while (keep_running) {
        struct sockaddr_in client_address;
        socklen_t address_length = sizeof(client_address);
        int client_fd = accept(listen_fd, (struct sockaddr *)&client_address, &address_length);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            if (!keep_running || errno == EBADF || errno == EINVAL) break;
            perror("accept"); continue;
        }
        ClientArgs *client = malloc(sizeof(*client));
        if (!client) { close(client_fd); continue; }
        client->socket_fd = client_fd;
        pthread_t thread;
        if (pthread_create(&thread, NULL, client_thread, client) == 0) pthread_detach(thread);
        else { handle_client(client_fd); close(client_fd); free(client); }
    }
    if (listen_fd >= 0) { close(listen_fd); listen_fd = -1; }
    curl_global_cleanup();
    printf("C scorecard server stopped.\n");
    return EXIT_SUCCESS;
}
