#!/usr/bin/env python3
"""Static checks for the standalone frontend and its inline JavaScript."""

from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import tempfile
import sys


class FrontendParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.page_views = {}
        self.body_page = None

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        element_id = attributes.get("id")
        if element_id:
            self.ids.append(element_id)

        if "page-view" in attributes.get("class", "").split():
            page = attributes.get("data-page")
            if page:
                self.page_views[page] = element_id

        if tag == "body":
            self.body_page = attributes.get("data-page")


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: check_frontend.py path/to/index.html")

    html_path = Path(sys.argv[1])
    html = html_path.read_text(encoding="utf-8")
    parser = FrontendParser()
    parser.feed(html)

    if len(parser.ids) != len(set(parser.ids)):
        raise SystemExit("Duplicate HTML id detected")

    expected = {
        "signin": "page-signin",
        "overview": "page-overview",
        "performance": "page-performance",
        "scorecard": "page-scorecard",
        "history": "page-history",
        "analyst": "page-analyst",
    }
    if parser.page_views != expected:
        raise SystemExit(f"Unexpected feature page views: {parser.page_views!r}")
    if parser.body_page != "signin":
        raise SystemExit("The default document route must remain Sign-In-first")
    if not re.search(r"@media\s*\(\s*prefers-reduced-motion\s*:\s*reduce\s*\)", html):
        raise SystemExit("Reduced-motion support is missing")

    scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", html, re.IGNORECASE | re.DOTALL)
    if not scripts:
        raise SystemExit("No inline JavaScript found to syntax-check")

    with tempfile.TemporaryDirectory() as directory:
        script_path = Path(directory) / "inline.js"
        script_path.write_text("\n".join(scripts), encoding="utf-8")
        subprocess.run(["node", "--check", str(script_path)], check=True)

    print(f"Frontend checks passed: {len(parser.ids)} unique IDs, six page views, reduced motion, inline JavaScript syntax.")


if __name__ == "__main__":
    main()
