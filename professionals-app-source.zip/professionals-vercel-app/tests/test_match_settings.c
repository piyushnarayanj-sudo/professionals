#define main scorecard_server_main
#include "../server.c"
#undef main

#include <stdio.h>

static int failures = 0;

static void expect(int condition, const char *message) {
    if (condition) return;
    fprintf(stderr, "FAIL: %s\n", message);
    failures++;
}

static int parse_body(const char *body, MatchSettingsInput *input, char *error, size_t capacity) {
    memset(input, 0, sizeof(*input));
    memset(error, 0, capacity);
    return parse_match_settings_input(body, input, error, capacity);
}

static void expect_webp_route(const char *path) {
    int sockets[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) != 0) {
        expect(0, "socket pair opens for WebP asset route");
        return;
    }
    char request[512];
    int length = snprintf(request, sizeof(request), "GET %s HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n", path);
    expect(length > 0 && (size_t)length < sizeof(request), "WebP asset request formats");
    if (length <= 0 || (size_t)length >= sizeof(request) || send_all(sockets[1], request, (size_t)length) != 0) {
        expect(0, "WebP asset request is sent");
        close(sockets[0]); close(sockets[1]);
        return;
    }
    handle_client(sockets[0]);
    shutdown(sockets[0], SHUT_WR);
    char response[2048];
    ssize_t received = recv(sockets[1], response, sizeof(response)-1, 0);
    if (received < 0) received = 0;
    response[received] = '\0';
    expect(strstr(response, "HTTP/1.1 200 OK") != NULL, "WebP image route returns HTTP 200");
    expect(strstr(response, "Content-Type: image/webp") != NULL, "WebP image route has the correct MIME type");
    close(sockets[0]); close(sockets[1]);
}

static void expect_index_route(const char *path) {
    char temporary_root[] = "/tmp/professionals-index-XXXXXX";
    char *root = mkdtemp(temporary_root);
    expect(root != NULL, "temporary document root is created");
    if (!root) return;

    char saved_root[sizeof(document_root)];
    snprintf(saved_root, sizeof(saved_root), "%s", document_root);
    snprintf(document_root, sizeof(document_root), "%s", root);
    char index_path[1200];
    snprintf(index_path, sizeof(index_path), "%s/index.html", root);
    FILE *index = fopen(index_path, "wb");
    expect(index != NULL, "temporary index file opens");
    if (!index) {
        snprintf(document_root, sizeof(document_root), "%s", saved_root);
        rmdir(root);
        return;
    }
    fputs("index-route-ok", index);
    fclose(index);

    int sockets[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) != 0) {
        expect(0, "socket pair opens for HTML route");
        snprintf(document_root, sizeof(document_root), "%s", saved_root);
        unlink(index_path);
        rmdir(root);
        return;
    }
    char request[512];
    int length = snprintf(request, sizeof(request), "GET %s HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n", path);
    expect(length > 0 && (size_t)length < sizeof(request), "HTML route request formats");
    if (length <= 0 || (size_t)length >= sizeof(request) || send_all(sockets[1], request, (size_t)length) != 0) {
        expect(0, "HTML route request is sent");
        close(sockets[0]); close(sockets[1]);
        snprintf(document_root, sizeof(document_root), "%s", saved_root);
        unlink(index_path);
        rmdir(root);
        return;
    }
    handle_client(sockets[0]);
    close(sockets[0]);
    char response[512];
    size_t used = 0;
    while (used < sizeof(response) - 1) {
        ssize_t received = recv(sockets[1], response + used, sizeof(response) - 1 - used, 0);
        if (received <= 0) break;
        used += (size_t)received;
    }
    response[used] = '\0';
    expect(strstr(response, "HTTP/1.1 200 OK") != NULL, "HTML route returns HTTP 200");
    expect(strstr(response, "Content-Type: text/html") != NULL, "HTML route has the correct MIME type");
    expect(strstr(response, "index-route-ok") != NULL, "HTML route serves the application index");
    close(sockets[1]);
    snprintf(document_root, sizeof(document_root), "%s", saved_root);
    unlink(index_path);
    rmdir(root);
}

int main(void) {
    char error[256];
    MatchSettingsInput input;

    expect(parse_body(
        "{\"team_a_name\":\"  Hyderabad Sunrisers  \","
        "\"team_b_name\":\"Mumbai Indians\",\"batting_team\":\"team_b\",\"expected_version\":12}", 
        &input, error, sizeof(error)), "valid team settings parse");
    expect(strcmp(input.team_a_name, "Hyderabad Sunrisers") == 0, "team A is trimmed");
    expect(strcmp(input.team_b_name, "Mumbai Indians") == 0, "team B is retained");
    expect(input.batting_team == 1, "team B batting is parsed");
    expect(input.expected_version == 12, "expected version is parsed");

    expect(parse_body(
        "{\"team_a_name\":\"The \\\"A\\\" Eleven\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":1}",
        &input, error, sizeof(error)), "escaped quotation marks parse safely");
    expect(strcmp(input.team_a_name, "The \"A\" Eleven") == 0, "escaped quotes decode correctly");

    expect(parse_body(
        "{\"team_a_name\":\"\\u0926\\u0947\\u0915\\u094d\\u0915\\u0928\","
        "\"team_b_name\":\"Team B\",\"batting_team\":\"team_a\",\"expected_version\":2}",
        &input, error, sizeof(error)), "Unicode team names parse");
    expect(strlen(input.team_a_name) >= 9, "Unicode escape becomes UTF-8 bytes");

    expect(!parse_body(
        "{\"team_a_name\":\"   \",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":1}",
        &input, error, sizeof(error)), "blank team name is rejected after trimming");
    expect(strstr(error, "Team A") != NULL, "blank team error is specific");

    expect(!parse_body(
        "{\"team_a_name\":\"Team A\\u0001\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":1}",
        &input, error, sizeof(error)), "control characters are rejected");

    char long_name[62];
    memset(long_name, 'X', 61);
    long_name[61] = '\0';
    char long_body[512];
    snprintf(long_body, sizeof(long_body),
        "{\"team_a_name\":\"%s\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":1}", long_name);
    expect(!parse_body(long_body, &input, error, sizeof(error)), "more than 60 characters are rejected");

    expect(!parse_body(
        "{\"team_a_name\":\"Team A\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"unknown\",\"expected_version\":1}",
        &input, error, sizeof(error)), "unknown batting-team token is rejected");
    expect(!parse_body(
        "{\"team_a_name\":\"Team A\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":0}",
        &input, error, sizeof(error)), "zero expected version is rejected");
    expect(!parse_body(
        "{\"team_a_name\":\"Team A\",\"team_b_name\":\"Team B\","
        "\"batting_team\":\"team_a\",\"expected_version\":999999999999999999999999999999}",
        &input, error, sizeof(error)), "overflowing expected version is rejected without integer overflow");

    int integer = -1;
    expect(json_get_integer("{\"n\":2147483647}", "n", INT_MAX, &integer) && integer == INT_MAX,
           "integer parser accepts its exact maximum");
    expect(!json_get_integer("{\"n\":2147483648}", "n", INT_MAX, &integer),
           "integer parser rejects a value beyond its maximum");

    StringBuffer encoded;
    string_buffer_init(&encoded);
    string_buffer_json_string(&encoded, "A \"quote\" and a \\slash");
    expect(strcmp(encoded.data, "\"A \\\"quote\\\" and a \\\\slash\"") == 0,
           "JSON string output escapes quotes and backslashes");
    free(encoded.data);

    expect_index_route("/overview");
    expect_index_route("/overview/");
    expect_webp_route("/assets/match-arena-sunset.webp");
    expect_webp_route("/assets/match-arena-aerial.webp");
    expect_webp_route("/assets/match-arena-futuristic.webp");
    expect_webp_route("/assets/match-arena-fireworks-wide.webp");
    expect_webp_route("/assets/match-arena-fireworks-field.webp");

    if (failures) {
        fprintf(stderr, "%d match-settings test(s) failed.\n", failures);
        return EXIT_FAILURE;
    }
    puts("PASS: match settings validation, JSON escaping, Overview routes, and WebP asset routes");
    return EXIT_SUCCESS;
}
